<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/staff.php';
	  
	$database = new Database();
	$db = $database->getConnection();
	  
	$staff = new Staff($db);
    $data = json_decode(file_get_contents("php://input"));

    $staff->sa_id = $data->sa_id;

	$stmt = $staff->getAllSEAssign();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$detail = array(
				"id" => (int)$id,
				"sales_admin" => $sales_admin,
				"sales_executive" => $sales_executive
			);
			array_push($arr["records"], $detail);
		}
	}
	echo json_encode($arr);
?>