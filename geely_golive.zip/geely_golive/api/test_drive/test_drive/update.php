<?php
// required headers
header("Access-Control-Allow-Origin: *");
// header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../../config/database.php';
include_once '../../objects/test_drive.php';

date_default_timezone_set('Asia/Rangoon'); 
session_start();

$database = new Database();
$db = $database->getConnection();
 
$test_drive = new TestDrive($db);
$data = json_decode(file_get_contents("php://input"));

$test_drive->id = $data->id;
$test_drive->license_no = $data->license_no;
$test_drive->rta_no = $data->rta_no;
$test_drive->time_in = date("H:i", strtotime($data->time_in));
$test_drive->time_out = date("H:i", strtotime($data->time_out));
$test_drive->drive_route = $data->drive_route;
$test_drive->feedback = $data->feedback;
$test_drive->sales_executive = $data->sales_executive;
$test_drive->exterior = $data->exterior;
$test_drive->interior = $data->interior;
$test_drive->acceleration = $data->acceleration;
$test_drive->braking = $data->braking;
$test_drive->stability = $data->stability;
$test_drive->visibility = $data->visibility;
$test_drive->comfort = $data->comfort;
$test_drive->noice_level = $data->noice_level;
$test_drive->test_drive_entry_by = $_SESSION['user'];
$test_drive->test_drive_entry_date_time = date("Y-m-d H:i:s");	

$filess = glob('./upload_log/' . $data->id . '/*');
foreach($filess as $files) {    
    if(!in_array($files, $data->old_img)){
        unlink($files);
    }
}
$i = 0;
if(count($data->arr_img)>0){
    foreach ($data->arr_img as $value) {
        if (!is_dir('./upload_log/' . $data->id)) {
            mkdir('./upload_log/' . $data->id, 0777, true);
        }
        ++$i;
        $img = $value;
        $img_data = base64_decode(explode(',', $img)[1]);
        $file = "./upload_log/" . $data->id . "/" . date("Y_m_d_H_i_s_") . $i . ".png";
        $success = file_put_contents($file, $img_data);
    }
}

if($test_drive->update()){
	echo 'updated';
}else{
	echo 'error';
}
?>