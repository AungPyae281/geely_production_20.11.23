<?php
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	 
	include_once '../../config/database.php';
	include_once '../../objects/lookup_check_list.php';
	include_once '../../objects/pdi_check_list.php';
	include_once '../../objects/sales.php';
	 
	$database = new Database();
	$db = $database->getConnection();
	 
	$lookup_check_list = new LookupCheckList($db);
	$pdi_check_list = new PDICheckList($db);
	$sales = new Sales($db);
	$data = json_decode(file_get_contents("php://input"));

	$sales->oc_no = $data->oc_no;
	$sales->getOneRow();

	$pdi_check_list->oc_no = $data->oc_no;

	$stmt1 = $pdi_check_list->getOneRow();
	$row1 = $stmt1->fetch(PDO::FETCH_ASSOC);

	$lookup_check_list->check_list_name = $data->check_list_name;

	$stmt2 = $lookup_check_list->getAllRows();
	$num2 = $stmt2->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num2>0){
		while ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)){
			extract($row2);
			$detail = array(
				"id" => (int)$id,
				"category_id" => (int)$category_id,
				"category" => $category,
				"subcategory_id" => (int)$subcategory_id,
				"subcategory" => $subcategory,
				"check_list" => $check_list,
				"type" => $type,
				"order_no" => (int)$order_no,
				"category_order_no" => (int)$c_order_no,
				"group_order" => (int)$group_order,
				"val" => (($row1["cl_" . $id])?$row1["cl_" . $id]:"")
			);
			array_push($arr["records"], $detail);
		}
	}
	$arr["pdi_done"] = (int)$sales->pdi_done;
	$arr["ff_done"] = (int)$sales->ff_done;
	echo json_encode($arr);
?>