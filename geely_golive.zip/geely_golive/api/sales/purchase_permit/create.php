<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/purchase_permit.php';
	include_once '../../objects/sales.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$purchase_permit = new Purchase_Permit($db);
	$sales = new Sales($db);
	$data = json_decode(file_get_contents("php://input"));	

	if($_SESSION['staff_id']!=""){
		$purchase_permit->entry_date = date("Y-m-d H:i:s");
		$purchase_permit->permit_submission_date = $data->permit_submission_date;
		$purchase_permit->permit_received_date = $data->permit_received_date;

		$purchase_permit->oc_no = $data->oc_no;
		$purchase_permit->name = $data->name;
		$purchase_permit->nrc = $data->nrc;
		$purchase_permit->mobile_no = $data->mobile_no;
		$purchase_permit->email = $data->email;
		$purchase_permit->address = $data->address;
		$purchase_permit->sales_center = $data->sales_center;
		$purchase_permit->bank = $data->bank;
		$purchase_permit->ac_no = $data->ac_no;
		$purchase_permit->foreign_currency_balance = $data->foreign_currency_balance;
		$purchase_permit->balance_date = $data->balance_date;

		$purchase_permit->vehicle_type = $data->vehicle_type;
		$purchase_permit->brand = $data->brand;
		$purchase_permit->model_year = $data->model_year;
		$purchase_permit->engine_power = $data->engine_power;
		$purchase_permit->value = $data->value;
		$purchase_permit->country_of_origin = $data->country_of_origin;
		$purchase_permit->commission = $data->commission;
		$purchase_permit->according_to = $data->according_to;

		$purchase_permit->other_name = $data->other_name;
		$purchase_permit->other_nrc = $data->other_nrc;
		$purchase_permit->other_address = $data->other_address;
	 
		if($purchase_permit->exist()){
			if(!$purchase_permit->update()){
				$arr = array(
			        "message" => "erroru"
			    );
				echo json_encode($arr);
				die();
			}
		}else{
			if(!$purchase_permit->create()){
				$arr = array(
			        "message" => "errorc"
			    );
			    echo json_encode($arr);
				die();
			}
		}

		$sales->oc_no = $data->oc_no;
		$sales->getOneRow();

		$payment_percent = 0;

		if($sales->payment_type=="Cash"){
		    $payment_percent = ROUND((((int)$sales->p_amount/((int)$sales->selling_price - 1000000)) * 100), 2);
		}else{
		    $payment_percent = ROUND((((int)$sales->p_amount/(int)$sales->selling_price) * 100), 2);
		}

		if($data->pp_done==1){
			$sales->column_name = "pp_done"; 
			$sales->updateDone();
		}

		if($data->pp_done==1 && $payment_percent>=100){

			$sales->status = "Purchase Permit";
			$sales->processing = "Income Tax";

			if(!$sales->updateStatus()){
			    $arr = array(
			        "message" => "Status Update Error"
			    );
			    echo json_encode($arr);
			    die();
			}
		}
		$arr = array(
		    "message" => "updated"
		); 
	}else{
		$arr = array(
		    "message" => "session expire"
		); 
	}
	echo json_encode($arr);
?>	