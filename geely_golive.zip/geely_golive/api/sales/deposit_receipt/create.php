<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/deposit_receipt.php';	
    include_once '../../objects/payment.php'; 
	include_once '../../objects/sales.php';	
    include_once '../../objects/due_date_setting.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$deposit_receipt = new DepositReceipt($db);
	$payment = new Payment($db); 
	$sales = new Sales($db);
    $due_date_setting = new DueDateSetting($db);
	$data = json_decode($_POST['objArr']);

	if($_SESSION['staff_id']!=""){

		$targetPath = "";
		$img = "";

		$targetPathPayment = "";

		if(!empty($_FILES['file-dc']))
		{
			$ext = pathinfo($_FILES['file-dc']['name'], PATHINFO_EXTENSION);
			if($ext!=""){
				if (!is_dir('./upload/' . $data[0]->oc_no)) {
			        mkdir('./upload/' . $data[0]->oc_no, 0777, true);
			    }

				$newname = date("Y-m-d H-i-s") .  "." . $ext;
				$targetPath = './upload/' . $data[0]->oc_no . '/' . $newname;
				copy($_FILES['file-dc']['tmp_name'], $targetPath);
				$img = $newname;

				if($data[0]->o_payment_type!="HP"){
					if (!is_dir('../payment/upload/' . $data[0]->oc_no)) {
				        mkdir('../payment/upload/' . $data[0]->oc_no, 0777, true);
				    }

					$targetPathPayment = '../payment/upload/' . $data[0]->oc_no . '/' . $newname;
					copy($_FILES['file-dc']['tmp_name'], $targetPathPayment);
				}
			}	
		}

		$due_date_setting->process = "Payment (Sales)";
        $due_hour = $due_date_setting->getDueDayHour();

        $current_date_time = date("Y-m-d H:i:s");
        $deposit_receipt->payment_due_date_time = date('Y-m-d H:i:s', strtotime("+" . $due_hour . " hours", strtotime($current_date_time)));

		$deposit_receipt->oc_no = $data[0]->oc_no;
		$deposit_receipt->gl_code = $data[0]->gl_code;
		$deposit_receipt->gl_code_bank_or_cash = $data[0]->gl_code_bank_or_cash;
		$deposit_receipt->r_date = $data[0]->r_date;
		$deposit_receipt->r_payment_type = $data[0]->r_payment_type;
		$deposit_receipt->receipt_no = $data[0]->receipt_no;
		$deposit_receipt->receipt_img = $img;
		$deposit_receipt->entry_by = $_SESSION['user'];
		$deposit_receipt->entry_date_time = date("Y-m-d H:i:s"); 

		if($data[0]->o_payment_type!="HP"){
			$payment->oc_no = $data[0]->oc_no;
			$payment->gl_code = $data[0]->gl_code;
			$payment->gl_code_bank_or_cash = $data[0]->gl_code_bank_or_cash;
	        $payment->date = $data[0]->r_date;
	        $payment->paid_by = '';
	        $payment->receive_by = $_SESSION['user'];
	        $payment->amount = $data[0]->amount;
	        $payment->description = 'Deposit (First Payment)';
	        $payment->receipt = $img;
	        $payment->entry_date_time = date("Y-m-d H:i:s");

	        $deposit_receipt->updatePaymentDueDateTime();
	        if(!$payment->create()){
	        	$msg_arr = array(
					"message" => "Payment Create Error"
				);
				echo json_encode($msg_arr);
				die();
	        }
		}else{
			if($deposit_receipt->create()){  
				$msg_arr = array(
					"message" => "created"
				);
			}else{
				$msg_arr = array(
					"message" => "error"
				);
			}
		}
		$sales->oc_no = $data[0]->oc_no;
		$sales->status = "Deposit Collect";
		$sales->processing = "Payment";
		
		if(!$sales->updateStatus()){
			$msg_arr = array(
				"message" => "Status Update Error"
			);
			echo json_encode($msg_arr);
			die();
		}
		$msg_arr = array(
			"message" => "created"
		);
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>