<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sales.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$sales = new Sales($db);
	$data = json_decode($_POST['objArr']);

	if($_SESSION['staff_id']!=""){
		$targetPath = "";
		$img = "";

		if(!empty($_FILES['file-pn']))
		{
			$ext = pathinfo($_FILES['file-pn']['name'], PATHINFO_EXTENSION);
			if($ext!=""){
				if (!is_dir('./upload/' . $data[0]->oc_no)) {
			        mkdir('./upload/' . $data[0]->oc_no, 0777, true);
			    }

				$newname = "plate-no." . $ext;
				$targetPath = './upload/' . $data[0]->oc_no . '/' . $newname;
				move_uploaded_file($_FILES['file-pn']['tmp_name'], $targetPath);
				$img = $newname;
			}	
		}

		$sales->oc_no = $data[0]->oc_no;
		$sales->plate_no = $data[0]->plate_no;
		$sales->special_plate = $data[0]->special_plate;
		$sales->plate_no_img = $img;

		if($sales->updatePlateNo()){

			if($data[0]->pn_done==1){

				$sales->status = "Plate Number";
				$sales->processing = "Fill the Fuel";

				$sales->column_name = "pn_done";
				if($sales->updateDone()){
					if(!$sales->updateStatus()){
					    $arr = array(
					        "message" => "Status Update Error"
					    );
					    echo json_encode($arr);
					    die();
					}
				}

			}

			$arr = array(
				"message" => "updated"
			);
		}else{
		    $arr = array(
				"message" => "error"
			);
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>