<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';
    include_once '../../../config/_globle.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;

    $sales->getOnePrint();

    $arr = array(
        "id" => $sales->id,
        "date" =>  $sales->date,
        "oc_no" => $sales->oc_no, 
        "customer_id" => $sales->customer_id,
        "customer_name" => $sales->customer_name,
        "nrc_no" => $sales->nrc_no,
        "mobile_no" => $sales->mobile_no,
        "email" => $sales->email,
        "address" => $sales->address,
        "broker_id" => $sales->broker_id,
        "broker_name" => $sales->broker_name,
        "brand" => $sales->brand,      
        "model" => $sales->model,  
        "model_year" => $sales->model_year, 
        "grade" => $sales->grade, 
        "vin_no" => $sales->vin_no,
        "engine_no" => $sales->engine_no,    
        "exterior_color" => $sales->exterior_color,
        "interior_color" => $sales->interior_color,
        "sales_center" => $sales->sales_center,     
        "sales_type" => $sales->sales_type,
        "vehicle_price" => number_format($sales->vehicle_price),
        "commercial_tax" => number_format($sales->commercial_tax),
        "rtad_tax" => number_format($sales->rtad_tax),
        "promotion_code" => $sales->promotion_code,
        "promotion_discount" => number_format($sales->promotion_discount),
        "selling_price" => number_format($sales->selling_price),
        "payment_type" =>  $sales->payment_type,
        "bank" =>  $sales->bank,    
        "payment_percent" => $sales->payment_percent,
        "payment_term" => $sales->payment_term, 
        "same_as_buyer" => $sales->same_as_buyer,
        "rtad_name" => $sales->rtad_name,
        "rtad_nrc_no" => $sales->rtad_nrc_no,
        "rtad_mobile_no" => $sales->rtad_mobile_no, 
        "customer_type" => $sales->customer_type,
        "company_name" => $sales->company_name,
        "company_register_no" => $sales->company_register_no,
        "staff_id" => $sales->staff_id,
        "deposit" => number_format($sales->deposit), 
        "dc_due_date_time" => $sales->dc_due_date_time,  
        "signature_picture" => $app_url . (($sales->dc_due_date_time)?("api/sales/sales/upload/" . $sales->oc_no . "/signature.png"):("img/signature_dummy.png")),
        "staff_sig" => $app_url . (($sales->staff_sig)?"api/hr/staff/signature/" . $sales->staff_sig:"img/signature_dummy.png"),
        "staff_name" => $sales->staff_name
    ); 
    echo json_encode($arr); 
?>