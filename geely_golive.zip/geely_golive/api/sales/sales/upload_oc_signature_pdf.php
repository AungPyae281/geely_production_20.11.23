<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';   
    include_once '../../objects/due_date_setting.php';
    
    date_default_timezone_set('Asia/Rangoon'); 

    $database = new Database();
    $db = $database->getConnection();
     
    $sales = new Sales($db);  
    $due_date_setting = new DueDateSetting($db);
    $data = json_decode(file_get_contents("php://input"));

    $file_name = "";
    if(!empty($_FILES['file'])){
    	if (!is_dir('./upload/' . $_GET["oc_no"])) {
            mkdir('./upload/' . $_GET["oc_no"], 0777, true);
        }

        $newname = "oc-signature.pdf";
        $targetPath = './upload/' . $_GET["oc_no"] . "/" . $newname;
        move_uploaded_file($_FILES['file']['tmp_name'], $targetPath);

        $file_name = $newname;
    }

    $sales->oc_no = $_GET["oc_no"];

    $due_date_setting->process = "Deposit Collect";
    $due_hour = $due_date_setting->getDueDayHour();

    $current_date_time = date("Y-m-d H:i:s");
    $sales->dc_due_date_time = date('Y-m-d H:i:s', strtotime("+" . $due_hour . " hours", strtotime($current_date_time)));

    if($sales->updateDueDateTime()){
        $arr = array(
            "message" => "updated"
        );
    }else{
        $arr = array(
            "message" => "error"
        );
    }
    echo json_encode($arr);
?>