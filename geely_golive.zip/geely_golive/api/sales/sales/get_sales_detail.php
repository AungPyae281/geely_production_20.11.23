<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;
    $sales->getSalesDetail();

    $particular = "Brand: " . $sales->brand . "\r\nModel: " . $sales->model . "\r\nYear: " . $sales->model_year . "\r\nGrade: " . $sales->grade;

    $remaining_balance = (int)$sales->selling_price - (int)$sales->total_payment; 

    $payment_percent = ROUND((((int)$sales->total_payment/(int)$sales->selling_price) * 100), 2);

    $arr = array(
        "oc_no" => $sales->oc_no,
        "sales_center" => $sales->sales_center,

        "c_name" => $sales->c_name,
        "c_nrc_no" => $sales->c_nrc_no,
        "c_mobile_no" => $sales->c_mobile_no, 
        "c_township" => $sales->c_township, 

        "vin_no" => $sales->vin_no,
        "engine_no" => $sales->engine_no,
        "particular" => $particular,

        "payment_type" => $sales->payment_type,
        "total_payment" => number_format($sales->total_payment), 
        "payment_percent" => $payment_percent,
        "deposit" => number_format($sales->deposit),
        "remaining_balance" => number_format($remaining_balance),
        "processing" => $sales->processing,

        // Purchase Permit
        "pp_done" => (int)$sales->pp_done,
        // Purchase Permit

        // Income Tax
        "income_tax_amount" => number_format($sales->income_tax_amount),
        "it_done" => (int)$sales->it_done,
        "income_tax" => $sales->income_tax,
        "it_submission_date" => $sales->it_submission_date,
        "it_received_date" => $sales->it_received_date,
        // Income Tax

        // RTA Appointment
        "appointment_date" => $sales->appointment_date,
        "appointment_time" => date('h:i A', strtotime($sales->appointment_time)),
        "rta_office_location" => $sales->rta_office_location,
        "appt_done" => (int)$sales->appt_done,
        // RTA Appointment

        // Plate Number
        "plate_no" => $sales->plate_no,
        "special_plate" => (int)$sales->special_plate,
        "plate_no_img" => $sales->plate_no_img,
        "pn_done" => (int)$sales->pn_done,
        // Plate Number

        // Fill the Fuel
        "fuel_amount" => number_format((int)$sales->fuel_amount),
        "ff_done" => (int)$sales->ff_done,
        // Fill the Fuel

        // Handover 
        "handover_date" => $sales->handover_date,
        "handover_vehicle_img" => $sales->handover_vehicle_img,
        // Handover

        // Owner Book Handover
        "owner_book_img" => $sales->owner_book_img
        // Owner Book Handover
    ); 
    echo json_encode($arr);
?>