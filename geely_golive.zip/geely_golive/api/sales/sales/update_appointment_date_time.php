<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sales.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();
	 
	$sales = new Sales($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['staff_id']!=""){
		$sales->oc_no = $data->oc_no;
		$sales->appointment_date = $data->appointment_date;
		$sales->appointment_time = date("H:i", strtotime($data->appointment_time));
		$sales->rta_office_location = $data->rta_office_location;

		if($sales->updateAppointmentDateTime()){
			if($data->appt_done==1){

				$sales->status = "RTA Appointment";
				$sales->processing = "Plate Number";

				$sales->column_name = "appt_done";
				if($sales->updateDone()){
					if(!$sales->updateStatus()){
					    $arr = array(
					        "message" => "Status Update Error"
					    );
					    echo json_encode($arr);
					    die();
					}
				}

			}
			$arr = array(
				"message" => "updated"
			);
		}else{
		    $arr = array(
				"message" => "error"
			);
		}
	}else{
		$arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($arr);
?>