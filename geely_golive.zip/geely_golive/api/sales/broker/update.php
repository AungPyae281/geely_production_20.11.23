<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/broker.php';	
	include_once '../../objects/broker_bank_account.php';	

	$database = new Database();
	$db = $database->getConnection();
	 
	$broker = new Broker($db);
	$broker_bank_account = new BrokerBankAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$broker->id = $data->id;
	$broker->name = $data->name;
	$broker->gender = $data->gender;
	$broker->dob = $data->dob;
	$broker->nrc_no = $data->nrc_no;
	$broker->phone = $data->phone;
	$broker->email = $data->email;
	$broker->register_date = $data->register_date; 
	$broker->company = $data->company;
	$broker->address = $data->address;

	if($broker->update()){
		
		$broker_bank_account->broker_id = $broker->id;

		if($broker_bank_account->delete()){
			foreach ($data->bankInfo as $bankInfo) {
				$broker_bank_account->name = $bankInfo->name;
				$broker_bank_account->account_no = $bankInfo->account_no;

				$broker_bank_account->create();
			}
		}

		$arr = array(
			"id" => $broker->id,
			"message" => "updated"
		);
	}else{
		$arr = array(
			"message" => "error"
		);
	}
	echo json_encode($arr);
?>