<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/payment.php';

    $database = new Database();
    $db = $database->getConnection();
     
    $payment = new Payment($db);
    $data = json_decode(file_get_contents("php://input"));

    $payment->oc_no = $data->oc_no;
    $payment->getPaymentPercentNBalance();

    $stmt = $payment->getAllRows();
    $num = $stmt->rowCount();

    $detailInfo = array();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row); 
            $detail = array(
                "id" => (int)$id,
                "date" => $date,
                "gl_code" => $gl_code,
                "gl_code_bank_or_cash" => $gl_code_bank_or_cash,
                "paid_by" => $paid_by,
                "amount" => number_format($amount),
                "description" => $description,
                "receipt" => $receipt,
                "entry_date_time" => $entry_date_time
            );  
            array_push($detailInfo, $detail);
        }
    }

    $remaining_balance = (int)$payment->selling_price - (int)$payment->total_payment;
    $payment_percent = ROUND((($payment->total_payment/$payment->selling_price) * 100), 2);

    $arr = array(
        "payment_percent" => $payment_percent,
        "remaining_balance" => number_format($remaining_balance), 
        "detailInfo" => $detailInfo
    );
    echo json_encode($arr);
?>