<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/customer.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();

    $database = new Database();
    $db = $database->getConnection();

    $customer = new Customer($db); 

    $customer->staff_id = $_SESSION['staff_id'];

    $arr = array();
    $arr["data"] = array();

    $stmt = $customer->getAllCustomerList();
    $num = $stmt->rowCount();

    if($num>0){
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $detail = array(
                $registration_no,
                $staff_name,
                $name,
                $mobile_no,
                $sales_status,
                $id . "|" . $case_close
            );
            array_push($arr["data"], $detail);
        }
    }
    echo json_encode($arr);
?>