<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sales.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $sales = new Sales($db);
    $data = json_decode(file_get_contents("php://input"));

    $sales->oc_no = $data->oc_no;
    $sales->getOneRow();

    $arr = array();
    $arrDCOthers = array();

    if($sales->dc_others!=""){
        $splitDCOthers = explode("|", $sales->dc_others);
        foreach ($splitDCOthers as $value) {
            if($value!=""){
                array_push($arrDCOthers, $value);
            }
        }
    }

    $arr = array(
        "pp_done" => (int)$sales->pp_done,
        "dc_nrc" => $sales->dc_nrc,
        "dc_census" => $sales->dc_census,
        "dc_id" => $sales->dc_id,
        "dc_bl" => $sales->dc_bl,
        "dc_custom_statement" => $sales->dc_custom_statement,
        "dc_purchase_permit" => $sales->dc_purchase_permit,
        "dc_income_tax" => $sales->dc_income_tax,
        "dc_license" => $sales->dc_license,
        "dc_rta_fees_slip" => $sales->dc_rta_fees_slip, 
        "dc_sale_invoice" => $sales->dc_sale_invoice,
        "dc_sale_contract" => $sales->dc_sale_contract,
        "dc_delivery_note" => $sales->dc_delivery_note,
        "dc_owner_book" => $sales->dc_owner_book,
        "dc_others" => $arrDCOthers
    );
    echo json_encode($arr);
?>