<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: POST");
	header("Content-Type: application/json; charset=UTF-8");
	
	// include database and object files
	include_once '../config/database.php';
	include_once '../objects/route.php';
	session_start();
	 
	// instantiate database
	$database = new Database();
	$db = $database->getConnection();
	 
	// initialize object
	$route = new Route($db);
	$data = json_decode(file_get_contents("php://input"));
	
	$route->dashboard = $data->dashboard;
	$stmt = $route->getAllProcessWithAccess();
	$num = $stmt->rowCount();

	$arr = array();
	$arr["records"] = array();

	if($num>0){
		while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			extract($row);
			$r = array(
				"module" => $module,
				"process" => $process,
				"create" => $create,
				"read" => $read,
				"update" => $update,
				"delete" => $delete,
				"export" => $export,
				"print" => $print
			);
			array_push($arr["records"], $r);
		}
	}
	echo json_encode($arr);
?>