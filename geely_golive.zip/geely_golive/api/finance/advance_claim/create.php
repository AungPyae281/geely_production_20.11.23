<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/advance_claim.php';

    date_default_timezone_set('Asia/Rangoon'); 
    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $advance_claim = new AdvanceClaim($db);
    $data = json_decode($_POST['objArr']);

    $targetPath = "";
    $newname = "";

    if(!empty($_FILES['file']))
    {
        $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        $newname = date("Y-m-d H-i-s") .  "." . $ext;
        $targetPath = './upload/' . $newname;
        copy($_FILES['file']['tmp_name'], $targetPath);
    }
    $advance_claim->upload_receipt = $newname;  

    $advance_claim->date = $data[0]->date;
    $advance_claim->gl_code_to = $data[0]->gl_code_to;
    $advance_claim->amount = $data[0]->amount;
    $advance_claim->description = $data[0]->description;
    $advance_claim->advance_claim_by = $data[0]->advance_claim_by; 
    $advance_claim->gl_code_from = $data[0]->gl_code_from; 

    $advance_claim->entry_by = $_SESSION['user'];
    $advance_claim->entry_date_time = date("Y-m-d H:i:s");

    if($advance_claim->create()){
        $msg_arr = array(
            "message" => "created"
        );
    }else{
        $msg_arr = array(
            "message" => "error"
        );
    }
    echo json_encode($msg_arr);
?>