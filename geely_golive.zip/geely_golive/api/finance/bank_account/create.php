<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/bank_account.php';

	date_default_timezone_set('Asia/Rangoon');
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$bank_account = new BankAccount($db);
	$data = json_decode(file_get_contents("php://input"));

	$bank_account->gl_code = $data->gl_code;
	$bank_account->country = $data->country;
	$bank_account->bank_name = $data->bank_name; 
	$bank_account->branch = $data->branch;
	$bank_account->swift_code = $data->swift_code;
	$bank_account->currency = $data->currency;
	$bank_account->account_no = $data->account_no;
	$bank_account->account_name = $data->account_name;
	$bank_account->account_type = $data->account_type; 
	$bank_account->opening_balance = $data->opening_balance; 

    $bank_account->entry_by = $_SESSION['user'];
    $bank_account->entry_date_time = date("Y-m-d H:i:s");

	if($bank_account->isExist()){
		$msg_arr = array(
			"message" => "duplicate"
		);
	}else{
		if($bank_account->create()){
			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($msg_arr);
?>