<?php
    session_start();
    date_default_timezone_set('Asia/Rangoon');
    
    if(!isset($_SESSION['user'])){
		header("location:http://190.92.199.143/geely_golive/login.html");
    }else{
        $now = time(); // checking the time now when home page starts
        if($now > $_SESSION['expire'])
        {
            session_destroy();
            header("location:http://190.92.199.143/geely_golive/login.html");
        }
    }
?>