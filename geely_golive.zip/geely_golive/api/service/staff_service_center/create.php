<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/staff_service_center.php';

	date_default_timezone_set('Asia/Rangoon'); 
	session_start();

	$database = new Database();
	$db = $database->getConnection();

	$staff_service_center = new StaffServiceCenter($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$staff_service_center->staff_id = $data->staff_id;
		$staff_service_center->service_center_id = $data->service_center_id;
		$staff_service_center->service_center = $data->service_center;
		$staff_service_center->store_name = $data->store_name;
		$staff_service_center->entry_by = $_SESSION['user'];
		$staff_service_center->entry_date_time = date("Y-m-d H:i:s");

		if($staff_service_center->isExist()){
			$msg_arr = array(
				"message" => "duplicate"
			);
		}else{
			if($staff_service_center->create()){
				$msg_arr = array(
					"message" => "created"
				);
			}else{
				$msg_arr = array(
					"message" => "error"
				);
			}
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>