<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service.php';
	include_once '../../objects/service_detail_sparepart.php';
	include_once '../../objects/service_final_inspection.php';
    include_once '../../objects/due_date_setting.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service = new Service($db);
	$service_detail_sparepart = new ServiceDetailSparepart($db);
	$service_final_inspection = new ServiceFinalInspection($db);
    $due_date_setting = new DueDateSetting($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['service_center']!=""){

		$service_final_inspection->service_id = $data->id;
		$service_final_inspection->service_booklet = $data->service_booklet;
		$service_final_inspection->jack_and_handle = $data->jack_and_handle;
		$service_final_inspection->paking_sign = $data->paking_sign;
		$service_final_inspection->spare_wheel = $data->spare_wheel;
		$service_final_inspection->mobile_charger = $data->mobile_charger;
		$service_final_inspection->car_key = $data->car_key;
		$service_final_inspection->wheel_tax = $data->wheel_tax;
		$service_final_inspection->fuel_level = $data->fuel_level;
		$service_final_inspection->other_items = $data->other_items;
		$service_final_inspection->remark = $data->remark;
		$service_final_inspection->customer_complaint = $data->customer_complaint;
		$service_final_inspection->restored_position = $data->restored_position;
		$service_final_inspection->road_test_done = $data->road_test_done;
		$service_final_inspection->battery_health = $data->battery_health;
		$service_final_inspection->entry_date_time = date("Y-m-d H:i:s");

		if($service_final_inspection->create()){

			$due_date_setting->process = "Payment (After Sales)";
	        $due_hour = $due_date_setting->getDueDayHour();

	        $current_date_time = date("Y-m-d H:i:s");
			$service_detail_sparepart->invoice_date = date("Y-m-d");
	        $service_detail_sparepart->payment_due_date_time = date('Y-m-d H:i:s', strtotime("+" . $due_hour . " hours", strtotime($current_date_time)));

			$service_detail_sparepart->service_id = $data->id;
			$service_detail_sparepart->store_name = $_SESSION['store_name'];
			$service_detail_sparepart->updateByFinalInspection();

			$service->id = $data->id;
			$service->status = "Final Inspection";
			$service->updateStatus();

			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>