<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/service.php';
	include_once '../../objects/service_detail_service_item.php'; 

    date_default_timezone_set('Asia/Rangoon');
    session_start();

	$database = new Database();
	$db = $database->getConnection();

	$service = new Service($db);
	$service_detail_service_item = new ServiceDetailServiceItem($db); 
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$service->id = $data->id;
		$service->service_customer_id = $data->service_customer_id;
		$service->sa_id = $data->sa_id;
		$service->main_technician_id = $data->main_technician_id;
		$service->visit_type = $data->visit_type;
		$service->promotion = $data->promotion;
		$service->total_waiting_time = $data->total_waiting_time;
		$service->service_remark = $data->service_remark;
		$service->test_drive_agree = $data->test_drive_agree; 
		$service->discount = $data->discount;
		$service->status = $data->status;
		$service->service_entry_date_time = ($data->status!="")?date("Y-m-d H:i:s"):"";

		$service_detail_service_item->service_id = $data->id; 

		if($service->updateService()){

			$service_detail_service_item->delete();
			foreach ($data->service_detail as $detail) {
				$service_detail_service_item->service_type = $detail->service_type;
				$service_detail_service_item->package_id = $detail->package_id;
				$service_detail_service_item->package_name = $detail->package_name;
				$service_detail_service_item->item_code = $detail->item_code;
				$service_detail_service_item->item_name = $detail->item_name;
				$service_detail_service_item->item_wt = $detail->item_wt;
				$service_detail_service_item->item_price = $detail->item_price;
				$service_detail_service_item->package_price = $detail->package_price;
				$service_detail_service_item->warranty = $detail->warranty;
				$service_detail_service_item->technician_id = $detail->technician_id;
				$service_detail_service_item->bay_no = $detail->bay_no;
				$service_detail_service_item->start_time = $detail->start_time;
				$service_detail_service_item->end_time = $detail->end_time;

				if(!$service_detail_service_item->create()){
					$msg_arr = array(
						"message" => "Error Service Item"
					);
					echo json_encode($msg_arr);
					die();
				}
			}

			$msg_arr = array(
				"message" => "updated"
			);
		}else{
			$msg_arr = array(
				"message" => "error"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}
	echo json_encode($msg_arr);
?>