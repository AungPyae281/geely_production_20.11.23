<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';

    date_default_timezone_set('Asia/Rangoon');
    session_start();  

    $database = new Database();
    $db = $database->getConnection();

    $service = new Service($db); 

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['service_center']!=""){

        $service->service_center = $_SESSION['service_center'];
        
        $stmt = $service->getAllServicingList();
        $num = $stmt->rowCount();

        $arrStatus = ["Arrival Inspection", "Service", "Job Card", "Final Inspection"];

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    $registration_no,
                    $plate_no,
                    $vin_no, 
                    $contact_person,
                    $contact_phone,
                    number_format($kilometer),
                    $total_waiting_time,
                    $finish_services . '/' . $total_services,
                    $arrStatus[array_search($status, $arrStatus) + 1],
                    $id . '|' . $arrStatus[array_search($status, $arrStatus) + 1]
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>