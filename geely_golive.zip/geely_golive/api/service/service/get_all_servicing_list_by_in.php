<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");    
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';
    
    date_default_timezone_set('Asia/Rangoon');
    session_start();

    $database = new Database();
    $db = $database->getConnection();

    $service = new Service($db);

    $arr = array();
    $arr["data"] = array();

    if($_SESSION['service_center']!=""){

        $service->service_center = $_SESSION['service_center'];
        
        $stmt = $service->getAllServicingListByIN();
        $num = $stmt->rowCount(); 

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    $registration_no,
                    $service_center,
                    $service_date,
                    $plate_no,
                    $name,
                    $phone_no,
                    $sa_name,
                    $car_receive_date . (($car_receive_time!="")?(' ' . date('h:i A', strtotime($car_receive_time))):""),
                    $id,
                    $store_name,
                    $store_id
                );
                array_push($arr["data"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>