<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/service.php';

    session_start();

    $database = new Database();
    $db = $database->getConnection();
     
    $service = new Service($db);
    $data = json_decode(file_get_contents("php://input"));

    $arr = array();
    $arr["records"] = array();

    if($_SESSION['service_center']!=""){

        $service->date = $data->date;
        $service->registration_no = $data->registration_no;
        $service->service_center = $_SESSION['service_center'];
        $service->plate_no = $data->plate_no;
        $service->customer_name = $data->customer_name;
        $service->customer_phone = $data->customer_phone;

        $stmt = $service->search();
        $num = $stmt->rowCount();

        if($num>0){
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);
                $detail = array(
                    "id" => $id,
                    "date" => $car_receive_date,
                    "registration_no" => $registration_no,
                    "plate_no" => $plate_no,
                    "customer_name" => $customer_name,
                    "customer_phone" => $customer_phone,
                    "total_services" => number_format((int)$total_services),
                    "complain" => $complain
                );
                array_push($arr["records"], $detail);
            }
        }
    }
    echo json_encode($arr);
?>