<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/grade.php';
	include_once '../../objects/rtad_tax_change_log.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$grade = new Grade($db);
	$rtad_tax_change_log = new RTADTaxChangeLog($db);
	$data = json_decode(file_get_contents("php://input"));

	$grade->rtad_tax = $data->rtad_tax;

	$rtad_tax_change_log->change_date = $data->date;
	$rtad_tax_change_log->tax = $data->rtad_tax;
	$rtad_tax_change_log->entry_by = $_SESSION['user'];
	$rtad_tax_change_log->entry_date_time = date("Y-m-d H:i:s");

	foreach ($data->rtad_list as $rtad) {
		$grade->id = $rtad->id;
		$rtad_tax_change_log->grade_id = $rtad->id;

		if($grade->update()){
			if(!$rtad_tax_change_log->create()){
				$arr = array(
					"message" => "errorCreateLog"
				);
				echo json_encode($arr);
				die();
			}
		}else{
			$arr = array(
				"message" => "errorUpdateGrade"
			);
			echo json_encode($arr);
			die();
		}
	}
	$arr = array(
		"message" => "updated"
	);
	echo json_encode($arr);
?>