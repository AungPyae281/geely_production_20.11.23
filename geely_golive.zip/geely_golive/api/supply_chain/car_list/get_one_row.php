<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/car_list.php';
     
    $database = new Database();
    $db = $database->getConnection();

    $car_list = new CarList($db);
    $data = json_decode(file_get_contents("php://input"));

    $car_list->id = $data->id;

    $car_list->getOneRow();

    $interior_photo = array();
    $exterior_photo = array();

    $dir = "../../../upload/server/php/files/interior/" . $data->id;

    if(file_exists($dir)){
        $dh  = opendir($dir);
        while (false !== ($filename = readdir($dh))) {
            $filesIn[] = $filename;
        }
        rsort($filesIn);
        foreach($filesIn as $fileIn) {
            if ($fileIn != "." && $fileIn != ".." && $fileIn != "design" && $fileIn != "thumbnail") {
                $filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $fileIn);
                array_push($interior_photo, $fileIn);
            }
        }
    }

    $dir = "../../../upload/server/php/files/exterior/" . $data->id;

    if(file_exists($dir)){
        $dh  = opendir($dir);
        while (false !== ($filename = readdir($dh))) {
            $filesEx[] = $filename;
        }
        rsort($filesEx);
        foreach($filesEx as $fileEx) {
            if ($fileEx != "." && $fileEx != ".." && $fileEx != "design" && $fileEx != "thumbnail") {
                $filewithoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $fileEx);
                array_push($exterior_photo, $fileEx);
            }
        }
    }

    $detail = array(
        "id" => $car_list->id,
        "brand" => $car_list->brand,
        "model" => $car_list->model,
        "model_year" => $car_list->model_year,
        "grade" => $car_list->grade,
        "grade_id" => $car_list->grade_id,
        "engine_power" => $car_list->engine_power,
        "interior_color" => $car_list->interior_color,
        "exterior_color" => $car_list->exterior_color,
        "interior_photo" => $interior_photo,
        "exterior_photo" => $exterior_photo
    );
    echo json_encode($detail);
?>