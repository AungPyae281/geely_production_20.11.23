<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	  
	include_once '../../config/database.php';
	include_once '../../objects/car_list.php';
	include_once '../../objects/car_stock.php';
	
	date_default_timezone_set('Asia/Rangoon');
	  
	$database = new Database();
	$db = $database->getConnection();
	
	$car_list = new CarList($db);
	$car_stock = new CarStock($db);
	$data = json_decode(file_get_contents("php://input"));

	$arr = array();
	$arr["brands"] = array();
	$arr["modelNames"] = array();
	$arr["modelYears"] = array();
	$arr["grades"] = array();
	$arr["exteriorColors"] = array();
	$arr["interiorColors"] = array();
	$arr["prices"] = array();

	$car_list->date = date("Y-m-d");
	$car_stock->date = date("Y-m-d");
	$car_stock->vehicle_status = $data->vehicle_status;

	$stmt1 = (($data->vehicle_status=="Production")?$car_list->getAllBrandsByOC():$car_stock->getAllBrandsByOC());
	$num1 = $stmt1->rowCount();

	if($num1>0){	
		while ($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
			extract($row1);
			$detail = array(
				"brand" => $brand
			);
			array_push($arr["brands"], $detail);
		}	
	}

	$stmt2 = (($data->vehicle_status=="Production")?$car_list->getAllModelsByOC():$car_stock->getAllModelsByOC());
	$num2 = $stmt2->rowCount();

	if($num2>0){	
		while ($row2 = $stmt2->fetch(PDO::FETCH_ASSOC)){
			extract($row2);
			$detail = array(
				"brand" => $brand,
				"model_name" => $model
			);
			array_push($arr["modelNames"], $detail);
		}	
	}

	$stmt3 = (($data->vehicle_status=="Production")?$car_list->getAllModelYearsByOC():$car_stock->getAllModelYearsByOC());
	$num3 = $stmt3->rowCount();

	if($num3>0){	
		while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
			extract($row3);
			$detail = array(
				"brand" => $brand,
				"model_name" => $model,
				"model_year" => $model_year
			);
			array_push($arr["modelYears"], $detail);
		}	
	}

	$stmt4 = (($data->vehicle_status=="Production")?$car_list->getAllGradesByOC():$car_stock->getAllGradesByOC());
	$num4 = $stmt4->rowCount();

	if($num4>0){	
		while ($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
			extract($row4);
			$detail = array(
				"brand" => $brand,
				"model_name" => $model,
				"model_year" => $model_year,
				"grade" => $grade
			);
			array_push($arr["grades"], $detail);
		}	
	}

	$stmt5 = (($data->vehicle_status=="Production")?$car_list->getAllExteriorColorsByOC():$car_stock->getAllExteriorColorsByOC());
	$num5 = $stmt5->rowCount();

	if($num5>0){	
		while ($row5 = $stmt5->fetch(PDO::FETCH_ASSOC)){
			extract($row5);
			$detail = array(
				"brand" => $brand,
				"model_name" => $model,
				"model_year" => $model_year,
				"grade" => $grade,
				"exterior_color" => $exterior_color
			);
			array_push($arr["exteriorColors"], $detail);
		}	
	}

	$stmt6 = (($data->vehicle_status=="Production")?$car_list->getAllInteriorColorsByOC():$car_stock->getAllInteriorColorsByOC());
	$num6 = $stmt6->rowCount();

	if($num6>0){	
		while ($row6 = $stmt6->fetch(PDO::FETCH_ASSOC)){
			extract($row6);
			$detail = array(
				"brand" => $brand,
				"model_name" => $model,
				"model_year" => $model_year,
				"grade" => $grade,
				"exterior_color" => $exterior_color,
				"interior_color" => $interior_color
			);
			array_push($arr["interiorColors"], $detail);
		}	
	}

	$stmt7 = $car_list->getAllPricesByOC();
	$num7 = $stmt7->rowCount();

	if($num7>0){	
		while ($row7 = $stmt7->fetch(PDO::FETCH_ASSOC)){
			extract($row7);
			$detail = array(
				"brand" => $brand,
				"model_name" => $model,
				"model_year" => $model_year,
				"grade" => $grade,
				"exterior_color" => $exterior_color,
				"interior_color" => $interior_color,
				"vehicle_price" => number_format($vehicle_price),
				"rtad_tax" => number_format($rtad_tax)
			);
			array_push($arr["prices"], $detail);
		}	
	}
	echo json_encode($arr);
?>