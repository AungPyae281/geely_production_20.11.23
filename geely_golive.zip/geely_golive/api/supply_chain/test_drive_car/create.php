<?php
	// required headers
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/test_drive_car.php';

	$database = new Database();
	$db = $database->getConnection();
	 
	$test_drive_car = new TestDriveCar($db);
	$data = json_decode(file_get_contents("php://input"));

	$test_drive_car->model = $data->model;
	$test_drive_car->plate_no = $data->plate_no;

	if($test_drive_car->isExist()){
		$arr = array(
			"message" => "duplicate"
		);	
	}else{
		if($test_drive_car->create()){
		  	$arr = array(
				"message" => "created"
			);	
		}else{
			$arr = array(
				"message" => "error"
			);
		}
	}
	echo json_encode($arr);
?>	