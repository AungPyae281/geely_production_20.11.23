<?php
class ServicePromotionSparepart{ 
	private $conn;
	private $table_name = "service_promotion_sparepart"; 

	public $id;
	public $service_promotion_id;
	public $sparepart_code;
	public $discount_percent;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_promotion_id=:service_promotion_id, sparepart_code=:sparepart_code, discount_percent=:discount_percent";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_promotion_id", $this->service_promotion_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":discount_percent", $this->discount_percent);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE service_promotion_id=:service_promotion_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_promotion_id", $this->service_promotion_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getServicePromotionSparepart(){
		$query = " SELECT sps.*, sparepart.name FROM " . $this->table_name  . " AS sps LEFT JOIN sparepart ON sps.sparepart_code=sparepart.`code` WHERE sps.service_promotion_id=:service_promotion_id ORDER BY sps.id ";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_promotion_id", $this->service_promotion_id);
		$stmt->execute();
		return $stmt;
	} 
}
?>