<?php
class Driver{
	private $conn;
	private $table_name = "driver";

	public $id;
	public $name;
	public $nrc_no;
	public $phone;
	public $license_no;
	public $address;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllDrivers(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `name`";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}
}
?>