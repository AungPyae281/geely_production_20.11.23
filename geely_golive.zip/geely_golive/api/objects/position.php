<?php
class Position{
	    // database connection and table name
	private $conn;
	private $table_name = "position";

	// object properties

	public $id;
	public $department;
	public $position;

	public function __construct($db){
		$this->conn = $db;
	}

	function getAllRowsByDepartment(){
		$condition = "";	

		if($this->department){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " position.department =:department ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT position.*, IFNULL(staff.name, '') AS name FROM " . $this->table_name . " LEFT JOIN staff ON position.position=staff.position " . $condition . " GROUP BY position.position ORDER BY position.department, position.position";
		$stmt = $this->conn->prepare( $query );
		if($this->department) $stmt->bindParam(":department", $this->department);
		$stmt->execute();
		return $stmt;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE department = :department and position = :position LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->department=htmlspecialchars(strip_tags($this->department));
		$this->position=htmlspecialchars(strip_tags($this->position));

		$stmt->bindParam(":department", $this->department);
		$stmt->bindParam(":position", $this->position);

		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET department=:department, position=:position";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":department", $this->department);
		$stmt->bindParam(":position", $this->position);
		if($stmt->execute()){
			return true;
		}
		return false;		
	} 

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllPosition(){
		$condition = "";	

		if($this->position){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " `position` <> :position ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " GROUP BY `position` ORDER BY `position`";
		$stmt = $this->conn->prepare( $query );
		if($this->position) $stmt->bindParam(":position", $this->position);
		$stmt->execute();
		return $stmt;
	}
}
?>