<?php
class ServicePackageDetail{ 
	private $conn;
	private $table_name = "service_package_detail"; 

	public $id;
	public $service_package_id;
	public $service_item_id;

	public function __construct($db){
		$this->conn = $db;
	}

	function getServicePackageDetail(){
		$query = "SELECT spd.*, si.code, si.`name` AS service_item, sp.package_name, si.price, si.waiting_time FROM service_package_detail AS spd
LEFT JOIN service_package AS sp ON spd.service_package_id=sp.id
LEFT JOIN service_item AS si ON spd.service_item_id=si.id WHERE spd.service_package_id=:service_package_id ORDER BY spd.id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_package_id", $this->service_package_id);
		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE service_package_id = :service_package_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_package_id", $this->service_package_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_package_id=:service_package_id, service_item_id=:service_item_id"; 
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_package_id", $this->service_package_id);
		$stmt->bindParam(":service_item_id", $this->service_item_id);

		if($stmt->execute()){
			return true;
		}
		return false;		
	} 
}
?>