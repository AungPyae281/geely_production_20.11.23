<?php
class TestDrive{
	    // database connection and table name
	private $conn;
	private $table_name = "test_drive";

	// object properties

	public $id;
	public $customer_id;
	public $sales_executive_id;
	public $license_no;
	public $date;
	public $time;
	public $model;
	public $plate_no;	
	public $time_in;
	public $time_out;
	public $drive_route;
	public $feedback;
	public $sales_executive;
	public $agree;
	public $exterior;
	public $interior;
	public $acceleration;
	public $braking;
	public $stability;
	public $visibility;
	public $comfort;
	public $noice_level;
	public $booking_entry_by;
	public $booking_entry_date_time;
	public $test_drive_entry_by;
	public $test_drive_entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET customer_id=:customer_id, sales_executive_id=:sales_executive_id, `date`=:date, time=:time, model=:model, plate_no=:plate_no, booking_entry_by=:booking_entry_by, booking_entry_date_time=:booking_entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":customer_id", $this->customer_id);
		$stmt->bindParam(":sales_executive_id", $this->sales_executive_id);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":time", $this->time);
		$stmt->bindParam(":model", $this->model);
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":booking_entry_by", $this->booking_entry_by);
		$stmt->bindParam(":booking_entry_date_time", $this->booking_entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE id = ?";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(1, $this->id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateBooking(){
		$query = "UPDATE " . $this->table_name . " SET `date`=:date, time=:time, model=:model, plate_no=:plate_no, booking_entry_by=:booking_entry_by WHERE id=:id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":time", $this->time);
		$stmt->bindParam(":model", $this->model);	
		$stmt->bindParam(":plate_no", $this->plate_no);
		$stmt->bindParam(":booking_entry_by", $this->booking_entry_by);
		
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function updateAgree(){
		$query = "UPDATE " . $this->table_name . " SET agree=1 WHERE id=:id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET license_no=:license_no, time_in=:time_in, time_out=:time_out, drive_route=:drive_route, feedback=:feedback, sales_executive=:sales_executive, exterior=:exterior, interior=:interior, acceleration=:acceleration, braking=:braking, stability=:stability, visibility=:visibility, comfort=:comfort, noice_level=:noice_level, test_drive_entry_by=:test_drive_entry_by, test_drive_entry_date_time=:test_drive_entry_date_time WHERE id=:id";

		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":license_no", $this->license_no);	
		$stmt->bindParam(":time_in", $this->time_in);	
		$stmt->bindParam(":time_out", $this->time_out);
		$stmt->bindParam(":drive_route", $this->drive_route);
		$stmt->bindParam(":feedback", $this->feedback);
		$stmt->bindParam(":sales_executive", $this->sales_executive);
		$stmt->bindParam(":exterior", $this->exterior);
		$stmt->bindParam(":interior", $this->interior);
		$stmt->bindParam(":acceleration", $this->acceleration);
		$stmt->bindParam(":braking", $this->braking);
		$stmt->bindParam(":stability", $this->stability);
		$stmt->bindParam(":visibility", $this->visibility);
		$stmt->bindParam(":comfort", $this->comfort);
		$stmt->bindParam(":noice_level", $this->noice_level);
		$stmt->bindParam(":test_drive_entry_by", $this->test_drive_entry_by);
		$stmt->bindParam(":test_drive_entry_date_time", $this->test_drive_entry_date_time);
		
		if($stmt->execute()){
			return true;
		}	 
		return false;
	}

	function getOneRow(){
		$query = "SELECT *, registration_no, name, mobile_no FROM " . $this->table_name . " LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE test_drive.id=:id LIMIT 0,1";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->registration_no = $row['registration_no'];
			$this->name = $row['name'];
			$this->mobile_no = $row['mobile_no'];	
			$this->model = $row['model'];
			$this->plate_no = $row['plate_no'];
			$this->date = $row['date'];
			$this->time = $row['time'];
			$this->license_no = $row['license_no'];	
			$this->time_out = $row['time_out'];
			$this->time_in = $row['time_in'];
			$this->drive_route = $row['drive_route'];
			$this->feedback = $row['feedback'];
			$this->sales_executive = $row['sales_executive'];
			$this->agree = $row['agree'];
			$this->exterior = $row['exterior'];
			$this->interior = $row['interior'];
			$this->acceleration = $row['acceleration'];
			$this->braking = $row['braking'];
			$this->stability = $row['stability'];
			$this->visibility = $row['visibility'];
			$this->comfort = $row['comfort'];
			$this->noice_level = $row['noice_level'];
		}
	}

	function getAllTestDriveBooking(){
		$query = "SELECT test_drive.id, test_drive.license_no, test_drive.time, test_drive.model, name, mobile_no FROM " . $this->table_name . " LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE time_out='' AND test_drive.`date`=:date ORDER BY test_drive.time";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function getAllBookingList(){
		$query = "SELECT test_drive.*, registration_no, name, mobile_no FROM " . $this->table_name . " LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE time_out='' AND test_drive.sales_executive_id=:id ORDER BY test_drive.booking_entry_date_time DESC";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		return $stmt;
	}

	function getTodayTestDriveBooking(){	
		$query = "SELECT test_drive.*, registration_no, name, mobile_no FROM " . $this->table_name . " LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE agree=1 AND time_out='' ORDER BY test_drive.booking_entry_date_time DESC";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getTodayTestDriveBySE(){
		$query = "SELECT test_drive.id, `date`, `time`, `name`, mobile_no, model, plate_no FROM " . $this->table_name . " LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE agree=0 AND `date`=:date AND test_drive.sales_executive_id=:id ORDER BY test_drive.booking_entry_date_time DESC";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";

		if($this->df){	
			$condition .= " AND test_drive.`date`>=:df ";
		}

		if($this->dt){	
			$condition .= " AND test_drive.`date`<=:dt ";
		}

		if($this->name){	
			$condition .= " AND (test_drive.name LIKE  :name '%' or test_drive.name LIKE '%' :name '%' or test_drive.name Like '%' :name ) ";
		}

		if($this->model){	
			$condition .= " AND test_drive.model=:model ";
		}

		if($this->status=="finished"){	
			$condition .= " AND test_drive.time_in<>'' ";
		}

		if($this->status=="unfinish"){	
			$condition .= " AND test_drive.time_in='' ";
		}	

		if($this->userrole=="Showroom Manager"){
			$query = "SELECT test_drive.*, `name`, mobile_no FROM (
SELECT employee_id
FROM HR_incharge
WHERE incharge_id=:eid) AS st
LEFT JOIN test_drive ON st.employee_id=test_drive.sales_executive_id LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE customer_id IS NOT NULL " . $condition . " ORDER BY test_drive.booking_entry_date_time";
		}else{
			$query = "SELECT test_drive.*, name, mobile_no FROM " . $this->table_name . " LEFT JOIN customer ON test_drive.customer_id=customer.id WHERE customer_id IS NOT NULL " . $condition . " ORDER BY test_drive.booking_entry_date_time";
		}

		$stmt = $this->conn->prepare($query);

		if($this->userrole=="Showroom Manager") $stmt->bindParam(":eid", $this->eid);
		if($this->df) $stmt->bindParam(":df", $this->df);
		if($this->dt) $stmt->bindParam(":dt", $this->dt);
		if($this->name) $stmt->bindParam(":name", $this->name);
		if($this->model) $stmt->bindParam(":model", $this->model);

		$stmt->execute();
		return $stmt;
	}

	function getTotalTestDriveBooking(){
		$condition = "";

		if($this->id){
			if($condition!=""){ $condition .= " AND "; }
			$condition .= " sales_executive_id=:id ";
		}
		
		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT COUNT(*) AS total_test_drive_booking FROM " . $this->table_name . $condition;
		$stmt = $this->conn->prepare($query);	
		if($this->id) $stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return (int)$row['total_test_drive_booking'];
		}
	}

	function getTotalTestDriveBookingSM(){
		$query = "SELECT COUNT(*) AS total_test_drive_booking FROM (
SELECT employee_id
FROM HR_incharge
WHERE incharge_id=:id) AS st
LEFT JOIN test_drive ON st.employee_id=test_drive.sales_executive_id WHERE customer_id IS NOT NULL";
		$stmt = $this->conn->prepare($query);	
		$stmt->bindParam(":id", $this->id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return (int)$row['total_test_drive_booking'];
		}
	}

	function getTodayTestDriveCount(){
		$query = "SELECT COUNT(*) AS today_test_drive_count FROM " . $this->table_name . " WHERE agree=0 AND `date`=:date AND sales_executive_id=:id";
		$stmt = $this->conn->prepare($query);	
		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":date", $this->date);
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return (int)$row['today_test_drive_count'];
		}
	}
}
?>