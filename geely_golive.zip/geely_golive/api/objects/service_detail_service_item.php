<?php
class ServiceDetailServiceItem{ 
	private $conn;
	private $table_name = "service_detail_service_item";

	public $id;
	public $service_id;
	public $service_type;
	public $package_id;
	public $package_name;
	public $item_code;
	public $item_name;
	public $item_wt;
	public $item_price;
	public $package_price;
	public $warranty;
	public $technician_id;
	public $bay_no;
	public $start_time;
	public $end_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function generateDetailBySAI(){
		$query = "INSERT INTO service_detail_service_item (service_id, service_type, item_code, item_name, item_wt, item_price) SELECT :service_id, 'Item', service_item.code, service_item.name, service_item.waiting_time, service_item.price FROM service_appointment_item AS sai LEFT JOIN service_item ON sai.service_item_id=service_item.id WHERE sai.service_appointment_id=:appointment_id";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":appointment_id", $this->appointment_id);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getServiceDetail(){
		$query = "SELECT service_detail_service_item.*, staff.`name` AS technician_name FROM " . $this->table_name . " LEFT JOIN staff ON service_detail_service_item.technician_id=staff.id WHERE service_detail_service_item.service_id=:service_id ORDER BY service_detail_service_item.id, service_detail_service_item.item_code, service_detail_service_item.item_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->execute();
		return $stmt;
	} 

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE service_id=:service_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":service_id", $this->service_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET service_id=:service_id, service_type=:service_type, package_id=:package_id, package_name=:package_name, item_code=:item_code, item_name=:item_name, item_wt=:item_wt, item_price=:item_price, package_price=:package_price, warranty=:warranty, technician_id=:technician_id, bay_no=:bay_no, start_time=:start_time, end_time=:end_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_id", $this->service_id);
		$stmt->bindParam(":service_type", $this->service_type);
		$stmt->bindParam(":package_id", $this->package_id);
		$stmt->bindParam(":package_name", $this->package_name);
		$stmt->bindParam(":item_code", $this->item_code);
		$stmt->bindParam(":item_name", $this->item_name);
		$stmt->bindParam(":item_wt", $this->item_wt);
		$stmt->bindParam(":item_price", $this->item_price);
		$stmt->bindParam(":package_price", $this->package_price);
		$stmt->bindParam(":warranty", $this->warranty);
		$stmt->bindParam(":technician_id", $this->technician_id);
		$stmt->bindParam(":bay_no", $this->bay_no);
		$stmt->bindParam(":start_time", $this->start_time);
		$stmt->bindParam(":end_time", $this->end_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function updateJCProcessChange(){
		$query = "UPDATE " . $this->table_name . " SET technician_id=:technician_id, bay_no=:bay_no, start_time=:start_time, end_time=:end_time WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":technician_id", $this->technician_id);
		$stmt->bindParam(":bay_no", $this->bay_no);
		$stmt->bindParam(":start_time", $this->start_time);
		$stmt->bindParam(":end_time", $this->end_time);

		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>