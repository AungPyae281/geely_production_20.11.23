<?php
class SparepartWaitingListDetail{
	private $conn;
	private $table_name = "sparepart_waiting_list_detail";

	public $id;
	public $waiting_list_id;
	public $sparepart_code;
	public $sparepart_name;
	public $quantity;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET waiting_list_id=:waiting_list_id, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":waiting_list_id", $this->waiting_list_id);
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":quantity", $this->quantity);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getWaitingListDetail(){
		$query = "SELECT sparepart_waiting_list_detail.*, sparepart.sales_price FROM " . $this->table_name . " JOIN sparepart ON sparepart_waiting_list_detail.sparepart_code=sparepart.code WHERE waiting_list_id=:waiting_list_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":waiting_list_id", $this->waiting_list_id);
		$stmt->execute();
		return $stmt;
	}

	function delete(){
		$query = "DELETE FROM " . $this->table_name . " WHERE waiting_list_id=:waiting_list_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":waiting_list_id", $this->waiting_list_id);
		if($stmt->execute()){
			return true;
		}
		return false;	
	} 
}
?>