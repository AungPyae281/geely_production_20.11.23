<?php
class ServiceCenterStore{ 
	private $conn;
	private $table_name = "service_center_store";

    public $id;
    public $service_center_id;	
    public $service_center;
	public $sparepart_store_id;
	public $store_name;
	
	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `sparepart_store_id`=:sparepart_store_id LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET `service_center_id`=:service_center_id, service_center=:service_center, `sparepart_store_id`=:sparepart_store_id, store_name=:store_name";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":service_center_id", $this->service_center_id);
		$stmt->bindParam(":service_center", $this->service_center);
		$stmt->bindParam(":sparepart_store_id", $this->sparepart_store_id);
		$stmt->bindParam(":store_name", $this->store_name);

		if($stmt->execute()){
			return true;
		}
		return false;		
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " GROUP BY service_center ORDER BY service_center, store_name";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	} 

	 function getAllRowsForServiceCenterStore(){
		$query = "SELECT * FROM service_center_store ORDER BY service_center";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	} 
}
?>
