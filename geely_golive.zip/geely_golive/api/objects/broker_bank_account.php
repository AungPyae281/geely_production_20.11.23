<?php
class BrokerBankAccount{
	private $conn;
	private $table_name = "broker_bank_account";

	public $id;
	public $broker_id;
	public $name;
	public $account_no;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO `" . $this->table_name . "` SET 
		broker_id=:broker_id
		, name=:name
		, account_no=:account_no";
		 
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":broker_id", $this->broker_id);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":account_no", $this->account_no);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}
		return false;
    }

    function delete(){
		$query = "DELETE FROM `" . $this->table_name . "` WHERE broker_id=:broker_id";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":broker_id", $this->broker_id);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

    function getAllRowsByBroker(){
		$query = "SELECT * FROM `" . $this->table_name . "` WHERE broker_id=:broker_id ORDER BY id";
		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":broker_id", $this->broker_id);
		$stmt->execute();
		return $stmt;
	}
}
?>