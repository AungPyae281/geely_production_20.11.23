<?php
class ServiceCustomer{
    private $conn;
    private $table_name = "service_customer";
 
	public $id;
	public $registration_no; 
	public $name;
	public $nrc_no; 
	public $phone_no; 
	public $alternative_phone_no; 
	public $email;
	public $township;
	public $address;
	public $source;
	public $entry_by;
	public $entry_date_time;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE nrc_no=:nrc_no LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );	 
		$stmt->bindParam(":nrc_no", $this->nrc_no);		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row["id"];
			return true;
		}
		return false;
	}

	function generateCode($prefix){
		$query = "SELECT RIGHT(registration_no, 3) AS registration_no FROM `" . $this->table_name . "` WHERE LEFT(registration_no, 7)=:prefix ORDER BY registration_no DESC LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":prefix", $prefix);		
		$stmt->execute();
		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $prefix . sprintf("%03d", ((int)str_replace($prefix, "", $row['registration_no']) + 1));
		}else{
			return $prefix . "001";
		}
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET registration_no=:registration_no,
		 name=:name,
		 nrc_no=:nrc_no,
		 phone_no=:phone_no,
		 alternative_phone_no=:alternative_phone_no,
		 email=:email,  
		 township=:township, 
		 address=:address, 
		 source=:source, 
		 entry_by=:entry_by, 
		 entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->bindParam(":name", $this->name);
		$stmt->bindParam(":nrc_no", $this->nrc_no);
		$stmt->bindParam(":phone_no", $this->phone_no);
		$stmt->bindParam(":alternative_phone_no", $this->alternative_phone_no);
		$stmt->bindParam(":email", $this->email);
		$stmt->bindParam(":township", $this->township);
		$stmt->bindParam(":address", $this->address);
		$stmt->bindParam(":source", $this->source);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){
			$this->id = $this->conn->lastInsertId();
			return true;
		}	 
		return false;
	}

	function autocomplete(){
		$condition = "";
		
		if($this->registration_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (registration_no LIKE  :registration_no '%' or registration_no LIKE '%' :registration_no '%' or registration_no Like '%' :registration_no )";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT * FROM " . $this->table_name . $condition . " ORDER BY registration_no";
		$stmt = $this->conn->prepare($query);
		if($this->registration_no) $stmt->bindParam(":registration_no", $this->registration_no);
		$stmt->execute();
		return $stmt;
	}

	function search(){
		$condition = "";

		if($this->registration_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " registration_no=:registration_no ";
		}

		if($this->name){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (name LIKE  :name '%' or name LIKE '%' :name '%' or name Like '%' :name ) ";
		}

		if($this->phone_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (phone_no LIKE  :phone_no '%' or phone_no LIKE '%' :phone_no '%' or phone_no Like '%' :phone_no ) ";
		}

		if($this->township){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (`township` LIKE  :township '%' or `township` LIKE '%' :township '%' or `township` Like '%' :township ) ";
		}

		if($this->nrc_no){
			if($condition!=""){
				$condition .= " AND ";
			}
			$condition .= " (nrc_no LIKE  :nrc_no '%' or nrc_no LIKE '%' :nrc_no '%' or nrc_no Like '%' :nrc_no ) ";
		}

		if($condition!=""){
			$condition = " WHERE " . $condition;
		}

		$query = "SELECT service_customer.*, IFNULL(scar.no_of_vehicle, 0) AS no_of_vehicle FROM service_customer LEFT JOIN (SELECT service_customer_id, COUNT(service_customer_id) AS no_of_vehicle FROM service_car GROUP BY service_customer_id) AS scar ON service_customer.id=scar.service_customer_id " . $condition . " ORDER BY registration_no, name";

		$stmt = $this->conn->prepare($query);

		if($this->registration_no) $stmt->bindParam(":registration_no", $this->registration_no);
		if($this->name) $stmt->bindParam(":name", $this->name);
		if($this->phone_no) $stmt->bindParam(":phone_no", $this->phone_no);
		if($this->township) $stmt->bindParam(":township", $this->township);
		if($this->nrc_no) $stmt->bindParam(":nrc_no", $this->nrc_no);

		$stmt->execute();
		return $stmt;
	}

	function getServiceCustomer(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE id=:id LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		
		$stmt->bindParam(":id", $this->id);

		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->registration_no = $row['registration_no'];
			$this->name = $row['name'];
			$this->nrc_no = $row['nrc_no'];
			$this->phone_no = $row['phone_no'];
			$this->alternative_phone_no = $row['alternative_phone_no'];
			$this->email = $row['email'];
			$this->township = $row['township'];
			$this->address = $row['address'];
		}else{
			$this->id = "";
			$this->registration_no = "";
			$this->name = "";
			$this->nrc_no = "";
			$this->phone_no = "";
			$this->alternative_phone_no = "";
			$this->email = "";
			$this->township = "";
			$this->address = "";
		}
	} 

	function getAllCustomers(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY registration_no, name";
		$stmt = $this->conn->prepare($query);
		$stmt->execute();
		return $stmt;
	} 
}
?>