<?php
class ServicePackage{ 
	private $conn;
	private $table_name = "service_package"; 

	public $id;
	public $package_name;
	public $discount;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function isExist(){
		$query = "SELECT id FROM " . $this->table_name . " WHERE `package_name` = :package_name LIMIT 0,1";
		$stmt = $this->conn->prepare( $query );
		$this->package_name=htmlspecialchars(strip_tags($this->package_name));
		$stmt->bindParam(":package_name", $this->package_name);
		$stmt->execute();
		if($stmt->rowCount()>0){
			return true;
		}
		return false;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET package_name=:package_name";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":package_name", $this->package_name);
		if($stmt->execute()){
			return true;
		}
		return false;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY package_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getAllServicePackages(){
		$query = "SELECT sp.*, IFNULL(detail.total, 0) AS total FROM service_package AS sp
LEFT JOIN (SELECT service_package_id, SUM(price) AS total FROM service_package_detail AS spd
LEFT JOIN service_item AS si ON spd.service_item_id=si.id GROUP BY service_package_id) AS detail ON sp.id=detail.service_package_id ORDER BY package_name";
		$stmt = $this->conn->prepare( $query );
		$stmt->execute();
		return $stmt;
	}

	function getOneServicePackage(){
		$query = "SELECT * FROM " . $this->table_name . " WHERE id=:id LIMIT 0, 1";
		$stmt = $this->conn->prepare($query);
		$stmt->bindParam(":id", $this->id);
		if($stmt->execute()){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			$this->id = $row['id'];
			$this->discount = $row['discount'];
		}else{
			$this->id = "";
			$this->discount = 0;
		}
	} 

	function updatePackage(){
		$query = "UPDATE " . $this->table_name . " SET discount=:discount WHERE id=:id";
		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":discount", $this->discount);

		if($stmt->execute()){
			return true;
		}	 
		return false;
	} 

// 	function getAllRows(){
// 		$query = "SELECT service_package.*, IFNULL(spid.total, 0) AS total FROM " . $this->table_name . " LEFT JOIN (SELECT service_package_id, SUM(price) AS total
// FROM service_package_detail AS spd
// LEFT JOIN service_item ON spd.service_item_id=service_item.id
// GROUP BY service_package_id) AS spid ON service_package.id=spid.service_package_id order BY package_name";
// 		$stmt = $this->conn->prepare( $query );
// 		$stmt->execute();
// 		return $stmt;
// 	} 

	// function update(){
	// 	$query = "UPDATE " . $this->table_name . " SET package_name=:package_name where id=:id";
	// 	$stmt = $this->conn->prepare($query);

	// 	$stmt->bindParam(":id", $this->id);
	// 	$stmt->bindParam(":package_name", $this->package_name);

	// 	if($stmt->execute()){
	// 		return true;
	// 	}	 
	// 	return false;
	// } 
}
?>