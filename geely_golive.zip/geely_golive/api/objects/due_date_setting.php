<?php
class DueDateSetting{
	private $conn;
	private $table_name = "due_date_setting";

	public $id;
	public $process;
	public $due_day;
	public $due_hour;

	public function __construct($db){
		$this->conn = $db;
	}

	function getDueDayHour(){
		$query = "SELECT ((due_day * 24) + due_hour) AS `hour` FROM " . $this->table_name . " WHERE `process`=:process LIMIT 0, 1";

		$stmt = $this->conn->prepare( $query );
		$stmt->bindParam(":process", $this->process);
		$stmt->execute();

		if($stmt->rowCount()>0){
			$row = $stmt->fetch(PDO::FETCH_ASSOC);
			return (int)$row['hour'];
		}
		return 0;
	}

	function getAllRows(){
		$query = "SELECT * FROM " . $this->table_name . " ORDER BY `process`";
		$stmt = $this->conn->prepare($query);		
		$stmt->execute();
		return $stmt;
	}

	function update(){
		$query = "UPDATE " . $this->table_name . " SET due_day=:due_day, due_hour=:due_hour WHERE id=:id";
		$stmt = $this->conn->prepare($query);	

		$stmt->bindParam(":id", $this->id);
		$stmt->bindParam(":due_day", $this->due_day);
		$stmt->bindParam(":due_hour", $this->due_hour);	

		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>