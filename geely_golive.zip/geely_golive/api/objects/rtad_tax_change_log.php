<?php
class RTADTaxChangeLog{
    // database connection and table name
	private $conn;
	private $table_name = "rtad_tax_change_log";

	// object properties 
	public $id;
	public $grade_id;
	public $change_date;
	public $tax;
	public $entry_by;
	public $entry_date_time;

	public function __construct($db){
		$this->conn = $db;
	}

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET grade_id=:grade_id, change_date=:change_date, tax=:tax, entry_by=:entry_by, entry_date_time=:entry_date_time";

		$stmt = $this->conn->prepare($query);

		$stmt->bindParam(":grade_id", $this->grade_id);
		$stmt->bindParam(":change_date", $this->change_date);
		$stmt->bindParam(":tax", $this->tax);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time);

		if($stmt->execute()){ 
			return true;
		}
		return false;		
	}
}
?>