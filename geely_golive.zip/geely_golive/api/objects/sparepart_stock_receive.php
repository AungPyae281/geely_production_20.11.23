<?php
class SparepartStockReceive{
    private $conn;
    private $table_name = "sparepart_stock_receive";
  
	public $id;
	public $transfer_no;
	public $date;
	public $store_name; 
	public $sparepart_code;
	public $sparepart_name;
    public $quantity;
    public $receive_by;
	public $entry_by;
	public $entry_date_time;
	
    public function __construct($db){
        $this->conn = $db;
    }

	function create(){
		$query = "INSERT INTO " . $this->table_name . " SET transfer_no=:transfer_no, `date`=:date, store_name=:store_name, sparepart_code=:sparepart_code, sparepart_name=:sparepart_name, quantity=:quantity, receive_by=:receive_by, entry_by=:entry_by, entry_date_time=:entry_date_time";
		$stmt = $this->conn->prepare($query); 
	 
		$stmt->bindParam(":transfer_no", $this->transfer_no);
		$stmt->bindParam(":date", $this->date);
		$stmt->bindParam(":store_name", $this->store_name); 
		$stmt->bindParam(":sparepart_code", $this->sparepart_code);
		$stmt->bindParam(":sparepart_name", $this->sparepart_name);
		$stmt->bindParam(":quantity", $this->quantity);
		$stmt->bindParam(":receive_by", $this->receive_by);
		$stmt->bindParam(":entry_by", $this->entry_by);
		$stmt->bindParam(":entry_date_time", $this->entry_date_time); 

		if($stmt->execute()){
			return true;
		}
		return false;
	}
}
?>
