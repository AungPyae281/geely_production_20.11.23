<?php 
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	include_once '../../config/database.php';
	include_once '../../objects/sparepart_receiving.php';
	include_once '../../objects/sparepart_receiving_detail.php';
	include_once '../../objects/sparepart_order_detail.php';
	include_once '../../objects/sparepart_stock_in.php';
	include_once '../../objects/sparepart_stock_balance.php';

	session_start();
	date_default_timezone_set('Asia/Rangoon');

	$database = new Database();
	$db = $database->getConnection();

	$sparepart_receiving = new SparepartReceiving($db);
	$sparepart_receiving_detail = new SparepartReceivingDetail($db);
	$sparepart_order_detail = new SparepartOrderDetail($db);
	$sparepart_stock_in = new SparepartStockIn($db);
	$sparepart_stock_balance = new SparepartStockBalance($db);
	$data = json_decode(file_get_contents("php://input"));

	if($_SESSION['user']!=""){

		$sparepart_receiving->gic_code = $data->gic_code;
		$sparepart_receiving->receive_date = $data->receive_date;
		$sparepart_receiving->store = $data->store;
		$sparepart_receiving->receive_by = $data->receive_by;
		$sparepart_receiving->remark = $data->remark;
		$sparepart_receiving->entry_by = $_SESSION['user'];
		$sparepart_receiving->entry_date_time = date("Y-m-d H:i:s"); 

		$sparepart_stock_in->date = $data->receive_date;
		$sparepart_stock_in->order_id = $data->order_id; 
		$sparepart_stock_in->store_name = $data->store;  
		$sparepart_stock_in->entry_by = $sparepart_receiving->entry_by;
		$sparepart_stock_in->entry_date_time = $sparepart_receiving->entry_date_time; 

		$sparepart_stock_balance->store_name = $data->store;  

		if($sparepart_receiving->create()){
			$sparepart_receiving_detail->sparepart_receiving_id = $sparepart_receiving->id; 

			foreach ($data->spareparts_lists as $splist) { 
				$sparepart_receiving_detail->sparepart_pre_order_id = $splist->sparepart_pre_order_id;
				$sparepart_receiving_detail->sparepart_code = $splist->sparepart_code;
				$sparepart_receiving_detail->sparepart_name = $splist->sparepart_name; 
				$sparepart_receiving_detail->quantity = $splist->stock_in_quantity;

				if(!$sparepart_receiving_detail->create()){
					$msg_arr = array(
						"message" => "errorReceivingDetail"
					);
					echo json_encode($msg_arr);
					die();
				}

				$sparepart_order_detail->sparepart_order_id = $data->order_id;
				$sparepart_order_detail->sparepart_pre_order_id = $splist->sparepart_pre_order_id;
				$sparepart_order_detail->sparepart_code = $splist->sparepart_code;
				$sparepart_order_detail->receive_quantity = $splist->stock_in_quantity;

				if(!$sparepart_order_detail->updateReceiveQty()){
					$msg_arr = array(
						"message" => "errorOrderDetail"
					);
					echo json_encode($msg_arr);
					die();
				}

				$sparepart_stock_in->sparepart_code = $splist->sparepart_code;
				$sparepart_stock_in->sparepart_name = $splist->sparepart_name;
				$sparepart_stock_in->quantity = $splist->stock_in_quantity;
				
				if(!$sparepart_stock_in->create()){
					$msg_arr = array(
						"message" => "errorStockIn"
					);
					echo json_encode($msg_arr);
					die();
				} 

				$sparepart_stock_balance->sparepart_code = $splist->sparepart_code; 
				$sparepart_stock_balance->sparepart_name = $splist->sparepart_name; 
				$sparepart_stock_balance->total_stock_in = $splist->stock_in_quantity; 
				$sparepart_stock_balance->total_lock = ($splist->sparepart_pre_order_id==0)?0:(int)$splist->stock_in_quantity; 

				if($sparepart_stock_balance->isExist()){
					if(!$sparepart_stock_balance->updateFromReceiving()){
						$msg_arr = array(
							"message" => "errorStockBalanceUpdate"
						);
						echo json_encode($msg_arr);
						die();
					}
				}else{
					if(!$sparepart_stock_balance->create()){
						$msg_arr = array(
							"message" => "errorStockBalanceCreate"
						);
						echo json_encode($msg_arr);
						die();
					}
				}

			}
			$msg_arr = array(
				"message" => "created"
			);
		}else{
			$msg_arr = array(
				"message" => "errorC"
			);
		}
	}else{
		$msg_arr = array(
			"message" => "session expire"
		);
	}	
	echo json_encode($msg_arr);
?>