<?php 
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../objects/sparepart_stock_out.php';
    include_once '../../objects/sparepart_stock_balance.php';

    session_start();
     
    $database = new Database();
    $db = $database->getConnection();

    $sparepart_stock_out = new SparepartStockOut($db);
    $sparepart_stock_balance = new SparepartStockBalance($db);
    $data = json_decode(file_get_contents("php://input"));

    if($_SESSION['user']!=""){

        $sparepart_stock_out->id = $data->id;
         
        if($sparepart_stock_out->delete()){

            $sparepart_stock_balance->store_name = $data->store_name; 
            $sparepart_stock_balance->sparepart_code = $data->sparepart_code;
            $sparepart_stock_balance->reason = $data->reason;
            $sparepart_stock_balance->quantity = (int)$data->quantity;

            if($sparepart_stock_balance->updateFromStockOutDelete()){
                $msg_arr = array(
                    "message" => "deleted"
                );
            }    
        }else{
            $msg_arr = array(
                "message" => "error"
            );
        }
    }else{
        $msg_arr = array(
            "message" => "session expire"
        );
    }
    echo json_encode($msg_arr);
?>