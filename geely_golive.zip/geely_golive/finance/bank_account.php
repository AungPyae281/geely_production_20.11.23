<?php include '../header.php'; ?>
<style>
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Bank Account - Entry</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">Info</h3>
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">G/L Code: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboGLCode"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Country: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboCountry">
													<option value=""></option>
													<option value="Myanmar">Myanmar</option>
													<option value="Singapore">Singapore</option>
													<option value="China">China</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Bank Name: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBankName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Swift Code: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtSwiftCode">
											</div>
										</div>
									</div>
									<div class="col-md-4"> 
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Account No.: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtAccountNo">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Account Name: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtAccountName">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Account Type: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtAccountType">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Currency: </label>
											<div class="col-md-8">
												<select class="form-control" id="cboCurrency"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Opening Balance: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtOpeningBalance" value="0" style="text-align: right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Branch: </label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBranch">
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-8"></div>
											<div class="col-md-4">
												<button type="button" class="btn btn-success btn-block" onclick="create()">Add</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title">List <span id="total_records" style="font-weight:bold;"> </span></h3>
						</div>
						<div class="card-body p-0" style="max-height: 470px; overflow: auto;">
							<table class="table table-striped table-bordered" id="myTable">
								<thead>                  
									<tr>
										<th style="width: 3%; text-align: center; vertical-align: middle;">No.</th>
										<th style="text-align: center; vertical-align: middle;">G/L Code</th>
										<th style="text-align: center; vertical-align: middle;">Country</th>
										<th style="text-align: center; vertical-align: middle;">Bank Name</th>
										<th style="text-align: center; vertical-align: middle;">Branch</th>
										<th style="text-align: center; vertical-align: middle;">Swift Code</th>
										<th style="text-align: center; vertical-align: middle;">Account No.</th>
										<th style="text-align: center; vertical-align: middle;">Account Name</th>
										<th style="text-align: center; vertical-align: middle;">Account Type</th>
										<th style="text-align: center; vertical-align: middle;">Currency</th>
										<th style="text-align: center; vertical-align: middle;">Balance</th>
										<th style="text-align: center; vertical-align: middle;">Exchange Rate</th>
										<th style="text-align: center; vertical-align: middle;">Balance (MMK)</th>
										<th style='padding-right: 6px !important; text-align: center; vertical-align: middle;'>Transfer</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
	$(function() {
		$("body").addClass("sidebar-collapse");
		getAllUnregisterBankGL();
		getAllCurrency();
	});

	$("#cboCountry").change(function(){
		getAllBankAccount();
	});

	$("#cboCurrency").change(function(){
		getAllBankAccount();
	});

	$("#txtOpeningBalance").on("input", function(){
		isNumberDecimal(this);
	});

	function getAllUnregisterBankGL(){
        $("#cboGLCode").find("option").remove();
		$("#cboGLCode").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/finance/gl_account/get_all_unregister_bank_gl.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	$("#cboGLCode").append("<option value='" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
            });
        });
    }

	function getAllCurrency(){
        $("#cboCurrency").find("option").remove();
		$("#cboCurrency").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/finance/currency/get_all_rows.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
            	$("#cboCurrency").append("<option value='" + v.currency + "'>" + v.currency + "</option>");
            });
            getAllBankAccount();
        });
    }

	function create(){	 
		var gl_code = $("#cboGLCode").val();
		var country = $("#cboCountry").val();
		var bank_name = $("#txtBankName").val(); 
		var swift_code = $("#txtSwiftCode").val();
		var account_no = $("#txtAccountNo").val();
		var account_name = $("#txtAccountName").val();
		var account_type = $("#txtAccountType").val(); 
		var currency = $("#cboCurrency").val(); 
		var opening_balance = parseFloat($("#txtOpeningBalance").val().replace(/,/g, '')); 
		var branch = $("#txtBranch").val();

		if(gl_code==""){
			bootbox.alert("Please choose G/L code.");
		}else if(country==""){
			bootbox.alert("Please choose country.");
		}else if(bank_name==""){
			bootbox.alert("Please fill bank name.");
		}else if(swift_code==""){
			bootbox.alert("Please fill swift code.");
		}else if(account_no==""){
			bootbox.alert("Please fill account no.");
		}else if(account_name==""){
			bootbox.alert("Please fill account name.");
		}else if(account_type==""){
			bootbox.alert("Please fill account type.");
		}else if(currency==""){
			bootbox.alert("Please choose currency.");
		}else if(branch==""){
			bootbox.alert("Please fill branch.");
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/finance/bank_account/create.php",
				type: "POST",
				data: JSON.stringify({ gl_code: gl_code, country: country, bank_name: bank_name, swift_code: swift_code, account_no: account_no, account_name: account_name, account_type: account_type, currency: currency, opening_balance: opening_balance, branch: branch }),
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					$("#frmEntry")[0].reset();
					bootbox.alert("Successfully Added.");
					getAllUnregisterBankGL();
					getAllBankAccount();
				}else if(data.message=="duplicate"){
					bootbox.alert("Not allow duplicate account no.");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}		
	}

	function getAllBankAccount(){ 
		var country = $("#cboCountry").val();
        var currency = $("#cboCurrency").val();
        $("#myTable").find("tbody").find("tr").remove();
        $.ajax({
            type: "POST",
            url: APP_URL + "api/finance/bank_account/get_all_bank_account.php",
            data: JSON.stringify({ country: country, currency: currency })
        }).done(function(data) { 
            if(data.records.length>1){
            	$("#total_records").text(" - " + data.records.length + " records found.");
            }else{
            	$("#total_records").text(" - " + data.records.length + " record found.");
            }

            $.each(data.records, function(i, v) {
                $("#myTable").find("tbody")
                .append($('<tr>')
                    .append("<td>" + (i + 1) + "</td>")
                    .append("<td>" + v.gl_code + "</td>")
                    .append("<td>" + v.country + "</td>")
                    .append("<td>" + v.bank_name + "</td>")
                    .append("<td>" + v.branch + "</td>")
                    .append("<td>" + v.swift_code + "</td>") 
                    .append("<td><span style='color: blue; text-decoration: underline; cursor: pointer;' onclick='goToTransaction(this);'>" + v.account_no + "</span></td>")
                    .append("<td>" + v.account_name + "</td>")
                    .append("<td>" + v.account_type + "</td>")
                    .append("<td>" + v.currency + "</td>")
                    .append("<td style='text-align: right; padding-right: 20px;'>" + parseFloat(v.balance).toLocaleString() + "</td>")
                    .append("<td style='text-align: right; padding-right: 20px;'>" + ((v.exchange_rate)?parseFloat(v.exchange_rate).toLocaleString():"") + "</td>")
                    .append("<td style='text-align: right; padding-right: 20px;'>" + parseFloat(v.balance_mmk).toLocaleString() + "</td>")
                    .append("<td style='padding-right: 6px !important;'><button type='button' class='btn btn-success' style='min-width: 52px;' title='Transfer' onclick='goToTransfer(this);'><i class='fas fa-exchange-alt' style='font-size: 17px;'></i></button></td>")
                )
            });
        });
    }

    function goToTransaction(obj){
    	window.open(APP_URL + "finance/account_transaction.php?act=detail&glcode=" + $(obj).parent().parent().find("td").eq(1).text());
    }

    function goToTransfer(obj){
    	window.open(APP_URL + "finance/bank_account_transfer.php?act=entry&accno=" + $(obj).parent().parent().find("td").eq(6).text());
    }
 
	function isNumberDecimal(obj) {
        var val = obj.value;
        var re = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)$/g;
        var re1 = /^([0-9]+[\.]?[0-9]?[0-9]?|[0-9]+)/g;
        if(!re.test(val)) {
        	val = re1.exec(val);
            if (val) {
                obj.value = val[0];
            } else {
                obj.value = 0;
            }
        }
    }
</script>	
