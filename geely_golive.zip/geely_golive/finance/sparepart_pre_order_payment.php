<?php include '../header.php'; ?>
<?php
    $id = "";
    if(isset($_GET['id'])){
        if(!empty($_GET['id'])){
            $id = $_GET['id'];
        }
    }
?>
<style>
	.form-group {
		margin-bottom: 6px !important;
	}
	.form-control:disabled {
		background-color: #f8f8f9;
	}
	.col-form-label {
		padding-top: 3px !important;
	}
	select {
		padding-top: 1px !important;
	}
</style>
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Sparepart Pre Order Payment</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<button type="button" class="btn btn-primary" style="height: 33px; line-height: 0px; font-weight: bold; font-size: 16px; min-width: 65px; background-color: #fff; color: #000; border-color: #007bff;" id="btnGoBack" onclick="goToPreOrderList();"><i class="fas fa-arrow-left" style="margin-right: 6px;"></i> Go Back</button>
							<button type="button" class="btn btn-success" style="float: right; font-weight: bold;" onclick="goToPayment();" id="btnPayment">Add Payment</button>
						</div>
						<div class="card-body">
							<div class="row">
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Pre Order ID:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtPreOrderID" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Service Center:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtServiceCenter" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Pre Order Date:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtPreOrderDate" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Customer Name:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtCustomerName" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Customer Phone:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtCustomerPhone" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Plate No.:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtPlateNo" disabled>
										</div>
									</div>
								</div>
								<div class="col-md-4">
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Items:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtTotalItems" disabled style="text-align: right;">
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;">Total Quantity:</label>
										<div class="col-md-8">  
											<input type="text" class="form-control" id="txtTotalQuantity" disabled style="text-align: right;">
										</div>
									</div> 
									<div class="form-group row">
										<label class="col-md-4 col-form-label" style="text-align: right;"></label>
										<div class="col-md-8" style="text-align: right;">  
											<button type="button" class="btn btn-primary" onclick="goToDetail();" id="btnDetail">Sparepart Detail</button>
										</div>
									</div>
								</div>
							</div>	
							<div class="card-body p-0" style="max-height: 270px; overflow-y: auto; background-color: #e6e7e847 !important; margin-top: 20px;">
								<table class="table table-bordered" id="myTable">
									<thead>                  
										<tr>
											<th style="width: 5%;">No.</th>
											<th style="width: 10%;">Date</th>
											<th style="width: 10%;">G/L Code</th>
											<th style="width: 10%;">Account</th>
											<th>Paid By</th>
											<th>Receipt</th>
											<th>Description</th>
											<th style="text-align: right; width: 15%;">Payment</th>
										</tr>
									</thead>
									<tbody></tbody>
								</table>
							</div>
							<div class="row">
								<div class="col-md-8"></div>
								<div class="col-md-4" style="margin-top: 10px;">
									<div class="form-group row">
										<label class="col-md-6 col-form-label" style="text-align: right; font-size: 16px;">Total Payment:</label>
										<div class="col-md-6">  
											<input type="text" class="form-control" id="txtTotalPayment" style="text-align: right; padding-right: 24px; font-weight: bold; font-size: 16px;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-6 col-form-label" style="text-align: right; font-size: 16px;">Total Amount:</label>
										<div class="col-md-6">  
											<input type="text" class="form-control" id="txtTotalAmount" value="0" style="text-align: right; padding-right: 24px; font-weight: bold; font-size: 16px;" disabled>
										</div>
									</div>
									<div class="form-group row">
										<label class="col-md-6 col-form-label" style="text-align: right; font-size: 16px;">Balance:</label>
										<div class="col-md-6">  
											<input type="text" class="form-control" id="txtBalance" value="0" style="text-align: right; padding-right: 24px; font-weight: bold; font-size: 16px;" disabled>
										</div>
									</div>
								</div>
							</div>
						</div>

						<center>
							<div class="modal fade" id="myModalPayment">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 580px; top: 29px;">
										<div class="modal-header" style="padding: 12px;">
											<h4 class="modal-title" style="font-weight: bold;">Payment - Entry</h4>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
											<i class="fas fa-3x fa-sync-alt rotate360" style="margin: 70px 45%;"></i>
										</div>
										<div class="modal-body">
											<form role="form" id="frmEntry">
												<div class="row">
													<div class="col-md-12">
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Date: </label>
															<div class="col-md-7">  
																<div class="input-group input-append date" id="datePicker" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
																	<div class="input-group-prepend">
																		<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
																			<i class="far fa-calendar-alt"></i>
																		</span>
																	</div>
																	<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
																</div>
															</div>
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">G/L Code: </label>
															<div class="col-md-7">
																<select class="form-control" id="cboGLCode"></select>
															</div>
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Account: </label>
															<div class="col-md-7">
																<select class="form-control" id="cboBankCashAccount"></select>
															</div>
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Amount: </label>
															<div class="col-md-7">
																<input type="text" class="form-control" id="txtPayAmount" value="0" style="text-align:right;" onkeypress="return isNumber(event)" onkeyup="btozero(this);AddComma(this);">
															</div> 
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Paid By: </label>
															<div class="col-md-7">
																<input type="text" class="form-control" id="txtPaidBy">
															</div>
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Description:</label>
															<div class="col-md-7">
																<textarea class="form-control" id="txtDescription" rows="2"></textarea>
															</div>
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 control-label" style="text-align: right;">Upload Receipt:</label>
															<div class="col-md-7" style="text-align: left;">
																<input style="display:none" name="file" id="input-image-hidden" onchange="document.getElementById('previewing').src = window.URL.createObjectURL(this.files[0])" type="file" accept="image/jpeg, image/png" >
																<img id="previewing" name="previewing" src="<?=$app_url;?>img/no_image.jpg" style="height:133px; width:auto;cursor:pointer;"onclick="HandleBrowseClick('input-image-hidden');" title="Click to Change the Photo."> 
															</div>
															<div class="col-md-1"></div>
														</div>
														<div class="form-group row">
															<div class="col-md-4"></div>
															<div class="col-md-7" style="text-align: left;">
																<button type="button" class="btn btn-success" style="min-width: 140px;" id="btnSubmit">Make Payment</button>
															</div>
															<div class="col-md-1"></div>
														</div>
													</div>
												</div>
											</form>
										</div>
									</div>
								</div>
							</div>
						</center>

						<center>
							<div class="modal fade" id="myModalDetail">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 80%; top: 29px;">
										<div class="modal-header" style="padding: 12px;">
											<h4 class="modal-title" style="font-weight: bold;">Sparepart Detail</h4>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body" style="padding: 0px; max-height: 400px; overflow: auto;">
											<table class="table table-bordered" id="myTable1" style="margin-bottom: 0px;">
												<thead>                  
													<tr>
														<th style="width: 5%">No.</th>
														<th>Sparepart Code</th>
														<th>Sparepart Name</th>
														<th>Price</th>
														<th>Quantity</th>
														<th>Amount</th> 
													</tr>
												</thead>
												<tbody></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</center>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>
    var id = "<?= $id ?>";
	var d = new Date();
	var mm = (d.getMonth("MM") + 1);
	var dd = d.getDate();
	var yyyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);
	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");	
		$('#datePicker').datepicker();
        getAllGLCode();
        getAllBankAndCashAccount();
		getPreOrderPaymentDetail();
	});	

	function getAllGLCode(){
        $("#cboGLCode").find("option").remove();
        $("#cboGLCode").append("<option value=''></option>");
        $.ajax({
            url: APP_URL + "api/finance/gl_account/get_all_rows.php",
            type: "POST",
            data: JSON.stringify({ category: 'Customer' })
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboGLCode").append("<option value='" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
            });
        });
    }

    function getAllBankAndCashAccount(){ 
        $("#cboBankCashAccount").find("option").remove();
        $("#cboBankCashAccount").append("<option value=''></option>");

        $.ajax({
            url: APP_URL + "api/finance/bank_account/get_all_bank_and_cash_account.php"
        }).done(function(data) {
            $.each(data.records, function(i, v) {
                $("#cboBankCashAccount").append("<option value = '" + v.gl_code + "'>" + v.gl_code + " (" + v.name + ")</option>");
            });
        });
    }

	function getPreOrderPaymentDetail(){
		$.ajax({
			url: APP_URL + "api/sparepart/pre_order_payment/get_pre_order_payment_detail.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			if(parseInt(data.total_amount.replace(/,/g, ''))==parseInt(data.total_payment.replace(/,/g, ''))){
				$("#btnPayment").css("display", "none");
			}
			$("#txtPreOrderID").val(data.pre_order_id);
			$("#txtServiceCenter").val(data.service_center);
			$("#txtPreOrderDate").val(data.date);
			$("#txtCustomerName").val(data.customer_name);
			$("#txtPaidBy").val(data.customer_name);
			$("#txtCustomerPhone").val(data.customer_phone);
			$("#txtPlateNo").val(data.plate_no);
			$("#txtTotalItems").val(data.total_items); 
			$("#txtTotalQuantity").val(data.total_quantity); 

			$.each(data.payment_detail, function(i, v) {
				$("#myTable").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.date + "</td>")
					.append("<td>" + v.gl_code + "</td>")
					.append("<td>" + v.gl_code_bank_or_cash + "</td>")
					.append("<td>" + v.paid_by + "</td>")
					.append("<td><img src='" + v.upload_receipt + "' style='width: 100px;'></td>")
					.append("<td>" + v.description + "</td>")
					.append("<td style='text-align: right; padding-right: 24px !important;'>" + v.amount + "</td>")
				);
			});

			$("#txtTotalPayment").val(data.total_payment); 
			$("#txtTotalAmount").val(data.total_amount);
			$("#txtBalance").val(data.balance);
		});
	}

	$("#btnSubmit").click(function() {
		$("#frmEntry").submit();
	});

	$("#frmEntry").on('submit', (function(e) {
		e.preventDefault();
		var fileInput = $('#input-image-hidden')[0];
		var file = fileInput.files[0];
		var date = $("#txtDatePicker").val();
		var gl_code = $("#cboGLCode").val();
        var gl_code_bank_or_cash = $("#cboBankCashAccount").val();
		var amount = parseInt($("#txtPayAmount").val().replace(/,/g, ''));
        var paid_by = $("#txtPaidBy").val();
		var description = $("#txtDescription").val();
		var total_payment = parseInt($("#txtTotalPayment").val().replace(/,/g, ''));
		var balance = parseInt($("#txtBalance").val().replace(/,/g, ''));
		var min_deposit = (parseInt($("#txtTotalAmount").val().replace(/,/g, '')) * 0.5);

		if(gl_code=="") {
			bootbox.alert("Please choose G/L code.");
		}else if(gl_code_bank_or_cash == "") {
			bootbox.alert("Please choose account.");
		}else if(amount==0) {
			bootbox.alert("Please fill amount.");
		}else if(total_payment==0 && amount < min_deposit){
			bootbox.alert("First payment must be at least 50%."); 
		}else if(balance < amount) {
			bootbox.alert("Payment amount is exceed than balance!");
		}else if(paid_by.trim()==""){
            bootbox.alert("Please fill paid by.");
        }else{
    		$("#loading").css("display", "block");
		    var formData = new FormData();
		    var objArr = [];
		    objArr.push({
		    	"id" : id,
		    	"date" : date,
		    	"gl_code" : gl_code,
		    	"gl_code_bank_or_cash" : gl_code_bank_or_cash,
		    	"amount" : amount,
		    	"paid_by": paid_by,
		    	"description": description
		    });

		    formData.append('file', file);
		    formData.append('objArr', JSON.stringify(objArr));
		    $.ajax({
		    	url : APP_URL + "api/sparepart/pre_order_payment/create.php",
		    	type : "POST",
		    	processData : false,
		    	contentType : false,
		    	data : formData,
		    	success: function(data) {
		    		$("#loading").css("display", "none");
		    		if(data.message == "created") {
		    			bootbox.alert("Successfully make payment.");
		    			$("#txtDatePicker").val(customDate);
		    			$("#datePicker").datepicker("setDate", customDate);
		    			document.getElementById('previewing').src = APP_URL + "img/no_image.jpg";
		    			getAllGLCode();
		    			getAllBankAndCashAccount();
		    			$("#txtPayAmount").val(0);
		    			$("#txtDescription").val("");
		    			getPreOrderPaymentDetail();
						$("#myModalPayment").modal("hide");
		    		}else if(data.message=="session expire"){
						bootbox.alert("Session Expire! Please refresh the browser and login again.");
					}else{
		    			bootbox.alert("Error on server side.");
		    		}
		    	}
		    });
	  	}
	}));

	function goToPreOrderList(){
		document.location = APP_URL + "finance/sparepart_pre_order_list.php";
	}

	function goToPayment(){
		$("#myModalPayment").modal("show");
	}

	function goToDetail(){
		$("#myTable1").find("tbody tr").remove();
		$.ajax({
			url: APP_URL + "api/sparepart/pre_order/get_pre_order_detail.php",
			type: "POST",
			data: JSON.stringify({ id: id })
		}).done(function(data) {
			$.each(data.records, function(i, v) {
				$("#myTable1").find("tbody")
				.append($('<tr>')
					.append("<td>" + (i + 1) + "</td>")
					.append("<td>" + v.sparepart_code + "</td>")
					.append("<td>" + v.sparepart_name + "</td>")
					.append("<td  style='text-align:right; padding-right: 20px;'>" + v.price + "</td>")
					.append("<td  style='text-align:right; padding-right: 20px;'>" + v.quantity + "</td>")
					.append("<td  style='text-align:right; padding-right: 20px;'>" + v.amount + "</td>")
				);
			});
		});
		$("#myModalDetail").modal("show");
	}

	function HandleBrowseClick(input_image){
		var fileinput = document.getElementById(input_image);
		fileinput.click();
	}

	function btozero(obj){
		if($(obj).val() == "")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}

	function AddComma(obj) {
		var amount = $(obj).val().replace(/,/g, '');
		$(obj).val(parseInt(amount).toLocaleString());
	} 
</script>
