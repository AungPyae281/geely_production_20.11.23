<?php include '../header.php'; ?> 
<?php
	$cid = "";
	$rid = "";
	if(isset($_GET['cid'])){
		if(!empty($_GET['cid'])){
			$cid = $_GET['cid'];
		}
	}
	if(isset($_GET['rid'])){
		if(!empty($_GET['rid'])){
			$rid = $_GET['rid'];
		}
	}
?>  
<style>
	.col-form-label{
		padding-top: 4px !important;
	} 
	.toggle{
		min-height: 31px !important;
	}
	.toggle-on, .toggle-off{
		padding-left: 10px;
		padding-right: 10px;
	}
	select{
		padding-top: 1px !important;
		font-size: 14px !important;
	}
	#tblVOIPanel{
		max-height: 150px;
		overflow-y: auto;
	}
	#tblVOIList{
		height: 150px;
		background-color: #f2f2f2;
		margin-bottom: 0px;
	}
	#tblVOIList tbody tr td{
		padding: 5px;
	}
</style> 
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Customer - <?= (($cid)?"Edit":(($rid)?"Detail":"Entry")) ?></h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="overlay white" id="loading" style="display: none; position: absolute; width: 100%; height: 100%; z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body" style="padding-top: 10px;">
								<div class="row">
									<legend>Info
										<?php if($cid!="" || $rid!=""){ ?>
											<span style="float: right; font-size: 20px; color: #082c99;">Sales Executive - <b id="txtStaffName" data-id=""></b></span>
										<?php }else{ ?>
											<span style="float: right; font-size: 20px; color: #082c99;">Sales Executive - <b id="txtStaffName" data-id="<?= $_SESSION['staff_id'] ?>"><?= $_SESSION['staff_name'] ?></b></span>
										<?php } ?>
									</legend>
									<div class="col-md-6">	
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Registration No.:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtRegistrationNo" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; margin-top: -8px;">Name <span style="color: red;font-size: 20px;">*</span>:</label>
											<div class="col-md-7">
												<div class="input-group mb-3" style="margin-bottom: 0px !important;">	
													<div class="checkbox">
														<label class="checkbox-inline"  style="padding-left: 20px;">
															<input type="checkbox" data-toggle="toggle" id="chkGender" data-on="M" data-off="F" data-onstyle="success" checked>
														</label>
													</div>
													<input type="text" class="form-control" id="txtName">
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; margin-top: -8px;">Mobile No. <span style="color: red;font-size: 20px;">*</span>:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtMobileNo" onkeypress="return isNumber(event);">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; padding-top: 0px;">Best Time to Call <span style="color: red; font-size: 20px;">*</span>:</label>
											<div class="col-md-6">
												<div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkBTCAM" data-on="AM" data-off="AM" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkBTCPM" data-on="PM" data-off="PM" data-onstyle="success">
													</label>
												</div>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; margin-top: -8px;">Source of Inquiry <span style="color: red; font-size: 20px;">*</span>: </label>
											<div class="col-md-7">
												<div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIPhoneInOut" data-on="Ph. In/Out" data-off="Ph. In/Out" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIFacebook" data-on="Facebook" data-off="Facebook" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIAdvert" data-on="Advert" data-off="Advert" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIRoadShow" data-on="Road Show" data-off="Road Show" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOITelevision" data-on="Television" data-off="Television" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIWebsite" data-on="Website" data-off="Website" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIExistingCustomer" data-on="Exist Cus." data-off="Exist Cus." data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIReview" data-on="Review" data-off="Review" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIWalkIn" data-on="Walk In" data-off="Walk In" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOICarMagazine" data-on="Car Mag." data-off="Car Mag." data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIBroker" data-on="Broker" data-off="Broker" data-onstyle="success">
													</label>		
													<label class="checkbox-inline" style="padding-left: 20px; margin-bottom: 4px;">
														<input type="checkbox" data-toggle="toggle" id="chkSOIOther" data-on="Other" data-off="Other" data-onstyle="success">
													</label>
													<textarea class="form-control" id="txtSOIOtherRemark" rows="2"></textarea>
												</div>
											</div>
										</div>
										<div class="form-group row" style="margin-bottom: 6px !important;">
											<label class="col-md-5 col-form-label" style="text-align: right; margin-top: -8px;">Vehicle of Interest <span style="color: red;font-size: 20px;">*</span>:</label>
											<div class="col-md-7">
												<select class="form-control" id="cboVOIModelYear" style="width: 55%; display: inline-block !important;"></select>
												<select class="form-control" id="cboVOIGrade" style="width: 43%; display: inline-block !important;"></select>
											</div>
										</div>
										<div class="form-group row" style="margin-bottom: 6px !important;">
											<label class="col-md-5 col-form-label"></label>
											<div class="col-md-5">
												<select class="form-control" id="cboVOIColor"></select>
											</div>
											<div class="col-md-2" style="padding-left: 0px;">
												<button type="button" class="btn btn-success pull-right" onclick="addList();" style="width: 100%; font-size: 12px;"><i class="fa fa-plus" aria-hidden="true"></i></button>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;"></label>
											<div class="col-md-7" id="tblVOIPanel">
												<table class="table table-responsive-sm" id="tblVOIList">
													<tbody></tbody>
												</table>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; margin-top: -8px;">Sales Status<span style="color: red;font-size: 20px;">*</span>:</label>
											<div class="col-md-7">
												<div class="checkbox">
													<label class="checkbox-inline pToggle" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSalesStatusNormal" data-on="Normal" data-off="Normal" data-onstyle="success" class="ssToggle" checked value="Normal">
													</label>
													<label class="checkbox-inline pToggle" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSalesStatusWarm" data-on="Warm" data-off="Warm" data-onstyle="success" class="ssToggle" value="Warm">
													</label>
													<label class="checkbox-inline pToggle" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSalesStatusHot" data-on="Hot" data-off="Hot" data-onstyle="success" class="ssToggle" value="Hot">
													</label>
													<label class="checkbox-inline pToggle" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkSalesStatusDeal" data-on="Deal" data-off="Deal" data-onstyle="success" class="ssToggle" value="Deal">
													</label>
												</div>
											</div>
										</div>	
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Needs and Requirements:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtNeedsRequirements" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Estimate Delivery Date:</label>
											<div class="col-md-7">
												<div class="input-group input-append date" id="datePicker2" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker2" value="1982-06-15">
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Follow Up Until:</label>
											<div class="col-md-7">
												<div class="input-group input-append date" id="datePicker3" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker3" value="1982-06-15">
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Sales Center:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtSalesCenter" disabled value="<?=$_SESSION['sales_center']?>">
											</div>
										</div>	
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Alternative Telephone No.:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtAlternativeTelephoneNo" onkeypress="return isNumber(event);">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Home Phone:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtHomePhone" onkeypress="return isNumber(event);">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Email:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtEmail">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">DOB:</label>
											<div class="col-md-7">
												<div class="input-group input-append date" id="datePicker1" data-date="2020-02-04" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker1" value="1982-06-15">
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; padding-top: 0px;">Preferred Contact Method:</label>
											<div class="col-md-7">
												<div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkPCMMobile" data-on="Mobile" data-off="Mobile" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkPCMEmail" data-on="Email" data-off="Email" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkPCMOther" data-on="Other" data-off="Other" data-onstyle="success">
													</label>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Business:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtBusiness">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Township<span style="color: red;font-size: 20px;">*</span>: </label>
											<div class="col-md-7">
												<div class="input-group input-group">
													<input id="txtTownshipName" value='' class="form-control" disabled>
													<span class="input-group-btn">
														<button type="button" class="btn btn-primary" onclick="getAllTownship()" id="btnTownship" style="padding-bottom: 3px;">. . .</button>
													</span>         
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Address:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtAddress" rows="2"></textarea>
											</div>
										</div>	
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right; padding-top: 0px;">VIP:</label>
											<div class="col-md-6">
												<div class="checkbox">
													<label class="checkbox-inline"  style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkVIP" data-on="Yes" data-off="No" data-onstyle="success">
													</label>
												</div>
											</div>
											<div class="col-md-1"></div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Customer History:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtCustomerHistory" rows="2"></textarea>
											</div>
										</div>	
									</div>
								</div> 
								<div class="row" style="padding-top: 30px;">
									<legend>Current Vehicle</legend>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Brand/Model:</label>
											<div class="col-md-7">
												<input type="text" class="form-control" id="txtCVBrand">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Model Year:</label>
											<div class="col-md-7">
												<select class="form-control" id="cboCVModelYear"></select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">RTAD No.:</label>
											<div class="col-md-7" style="padding-right: 0px;">
												<input type="text" class="form-control" id="txtCVRTADNo1" style="text-align: right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Mileage (km):</label>
											<div class="col-md-2" style="padding-right: 0px;"> 
												<input type="text" class="form-control" id="txtCVMileage1" onkeypress="return isNumber(event);" style="text-align: right;">
											</div>
											<div class="col-md-5" style="padding-left: 0px;"> 
												<input type="text" class="form-control" id="txtCVMileage2" style="text-align: right;" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Vehicle us as commercial:</label>
											<div class="col-md-7">
												<div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkCVVehicleCommercial" data-on="Yes" data-off="No" data-onstyle="success">
													</label>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Outstanding Payments:</label>
											<div class="col-md-7">
												<div class="checkbox">
													<label class="checkbox-inline"  style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkCVOutstandingPayment" data-on="Yes" data-off="No" data-onstyle="success">
													</label>
												</div>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">What will it be used for:</label>
											<div class="col-md-7">
												<div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkCVPrivate" data-on="Private" data-off="Private" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkCVBusiness" data-on="Business" data-off="Business" data-onstyle="success">
													</label>	
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkCVOffRoad" data-on="Off Road" data-off="Off Road" data-onstyle="success">
													</label>
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkCVTravelling" data-on="Travelling" data-off="Travelling" data-onstyle="success">
													</label>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">What do you dislike about your car:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtCVDislikeAboutCar" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">What would you like to have that you don’t already have:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtCVWouldYouLikeToHaveThatNotAlreadyHave" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Annual Usage:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtCVAnnualUsage" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Who will be using the vehicle:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtCVWhoWillBeUsingVehicle" rows="2"></textarea>
											</div>
										</div>
									</div>
								</div>	
								<div class="row" style="padding-top: 30px;">
									<legend>Lifestyle</legend>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Family Members:</label>
											<div class="col-md-7">
												<select class="form-control" id="cboLifestyleFamilyMembers" style="text-align: right;">
													<option value="" dir="rtl"></option>
													<option value="1" dir="rtl">1</option>
													<option value="2" dir="rtl">2</option>
													<option value="3" dir="rtl">3</option>
													<option value="4" dir="rtl">4</option>
													<option value="5" dir="rtl">5</option>
													<option value="6" dir="rtl">6</option>
													<option value="7" dir="rtl">7</option>
													<option value="8" dir="rtl">8</option>
													<option value="9" dir="rtl">9</option>
													<option value="10" dir="rtl">10</option>
												</select>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Dream Brand:</label>
											<div class="col-md-7">
												<input class="form-control" id="txtLifeStyleDreamBrand">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Dream Car:</label>
											<div class="col-md-7">
												<input class="form-control" id="txtLifeStyleDreamCar">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Interested Model:</label>
											<div class="col-md-7">
												<input class="form-control" id="txtLifeStyleInterestedModel">
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Hobbies and Interests:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtLifestyleHobbiesInterests" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-5 col-form-label" style="text-align: right;">Customer’s Expectations of New Vehicle:</label>
											<div class="col-md-7">
												<textarea class="form-control" id="txtLifestyleExpectationsOfNewVehicle" rows="2"></textarea>
											</div>
										</div>
										<div class="form-group row">
											<div class="col-md-9"></div>
											<?php if($cid==""){ ?>
												<div class="col-md-3">
													<button type="button" id="btnSave" class="btn btn-success btn-block" onclick="validateAndSave()">Save</button>
												</div>
											<?php }else{ ?>
												<div class="col-md-3">
													<button type="button" class="btn btn-primary btn-block" onclick="validateAndUpdate()">Update</button>
												</div>
											<?php } ?>
										</div>	
									</div>
								</div>	 
							</div>
						</form>

						<center>
							<div class="modal fade" id="myModalTownshipList">
								<div class="modal-dialog" style="max-width: 100% !important;">
									<div class="modal-content" style="width: 65%; top: 30px;">
										<div class="modal-header">
											<h4 class="modal-title">Township List <span id="total_records" style="font-weight:bold;"> </span></h4>
											<button type="button" class="close" data-dismiss="modal" aria-label="Close">
												<span aria-hidden="true">&times;</span>
											</button>
										</div>
										<div class="modal-body">
											<table id="myTable1" class="table table-bordered table-hover">
												<thead style="background-color: #ecedee;">
													<tr>
														<th>State/Division</th>
														<th>City</th>
														<th>Township</th>
													</tr>
												</thead>
												<tbody style="cursor: pointer;"></tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</center>

					</div>
				</div>
			</div> 
		</div>
	</section>
</div> 
<?php include '../footer.php'; ?> 
<script>
	var grades = [];
	var colors = [];
	var rid = '<?=$rid;?>';
	var cid = '<?=$cid;?>';

	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var yyy = d.getFullYear();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$('#datePicker1').attr("data-date",customDate);
	$("#txtDatePicker1").val(customDate);
	$('#datePicker2').attr("data-date",customDate);
	$("#txtDatePicker2").val(customDate);
	$('#datePicker3').attr("data-date",customDate);
	$("#txtDatePicker3").val(customDate);

	$(function () { 
		$("body").addClass("sidebar-collapse");
		$("#txtStaffName").text('<?=$_SESSION['staff_name']?>');
		$("#txtStaffName").attr("data-id", '<?=$_SESSION['staff_id']?>');
		$('#datePicker1').datepicker();
		$('#datePicker2').datepicker();
		$('#datePicker3').datepicker();
		$(".toggle").css("height", "31.6px");
		$(".toggle").css("margin-right", "0px");	

		if(!$("#chkSOIOther").parent().hasClass("off")){
			$("#txtSOIOtherRemark").css("display", "");
		}else{
			$("#txtSOIOtherRemark").css("display", "none");
		}

		getAllVehiclesNColor();
		fillNumbers();
		addDate(14);

		if(rid){
			getCustomer();
			detailview();
		}else if(cid){
			getCustomer(); 
		}
	});	

	$('#txtCVMileage1').on('input', function(){
		var km = (isNaN(parseInt($(this).val()))==true)?"":parseInt($(this).val());
		if(km!=""){
			$("#txtCVMileage2").val(km * 1000);
		}else{
			$("#txtCVMileage2").val("");
		}
	});

	$(".ssToggle").change(function(){
		$(".ssToggle").parent().addClass('off');
		$(this).parent().removeClass("off");

		if($(this).val()=="Hot"){
			addDate(2);
			$("#txtDatePicker3").attr("disabled", true);
		}else if($(this).val()=="Normal" || $(this).val()=="Warm"){
			addDate(14);
			$("#txtDatePicker3").attr("disabled", false);
		}else{
			$("#txtDatePicker3").val(customDate);
			$("#datePicker3").datepicker("setDate", customDate);
			$("#txtDatePicker3").attr("disabled", false);
		}
	});		

	$("#chkSOIOther").change(function(){
		if(!$(this).parent().hasClass("off")){
			$("#txtSOIOtherRemark").css("display", "");
		}else{
			$("#txtSOIOtherRemark").css("display", "none");
		}
	});

	$("#cboVOIModelYear").change(function(){
		changeGrade();
		changeColor();
	});

	$("#cboVOIGrade").change(function(){
		changeColor();
	});

	function fillNumbers(){	
		var yy = d.getFullYear();
		$("#cboCVModelYear").append("<option value= ''>Year</option>");
		for (var i = yy; i >= 1990; i--){
			$("#cboCVModelYear").append("<option value= '" + i + "'>" + i + "</option>");
		}
	}

	function addDate(day){
		var currentDate = new Date();
		currentDate.setDate(currentDate.getDate() + day); //number  of days to add, e.g. 15 days
		var date = currentDate.toISOString().substr(0,10);
		$("#txtDatePicker3").val(date);
		$("#datePicker3").datepicker("setDate", date);
	}	
 
	function getAllVehiclesNColor(){
		grades = [];
		colors = [];
		$("#cboVOIModelYear").find("option").remove();
		$.ajax({
			url: APP_URL + "api/supply_chain/car_list/get_all_rows.php"
		}).done(function(data) {
			$.each(data.modelYear, function(i, v) {
				$("#cboVOIModelYear").append("<option value='" + v.model_year + "' data-model='" + v.model + "' data-year='" + v.year + "'>" + v.model_year + "</option>");
			});
			grades = data.grades;
			colors = data.colors;
			changeGrade();
			changeColor();
		});
	}

	function changeGrade(){
		$("#cboVOIGrade").find("option").remove();
		var model_year = $("#cboVOIModelYear").val();
		$.each(grades.filter(word => word.model_year==model_year), function(i, v) {
			$("#cboVOIGrade").append("<option value='" + v.grade + "' data-model-year='" + v.model_year + "' data-model='" + v.model + "' data-year='" + v.year + "'>" + v.grade + "</option>");
		});
	}

	function changeColor(){
		$("#cboVOIColor").find("option").remove();
		var model_year = $("#cboVOIModelYear").val();
		var grade = $("#cboVOIGrade").val();
		$.each(colors.filter(word => word.model_year==model_year && word.grade==grade), function(i, v) {
			$("#cboVOIColor").append("<option value='" + v.color + "' data-model-year='" + v.model_year + "' data-model='" + v.model + "' data-year='" + v.year + "' data-grade='" + v.grade + "'>" + v.color + "</option>");
		});
	}

	function addList(){
		if ($('#cboVOIModelYear').val()!="" && $('#cboVOIGrade').val()!="" && $('#cboVOIColor').val()!="" && !checkList($('#cboVOIModelYear').val(), $('#cboVOIGrade').val(), $('#cboVOIColor').val())){
			$("#tblVOIList").find("tbody")
			.append($("<tr data-model-year='" + $("#cboVOIModelYear").val() + "' data-model='" + $("#cboVOIModelYear option:selected").attr("data-model") + "' data-year='" + $("#cboVOIModelYear option:selected").attr("data-year") + "' data-grade='" + $("#cboVOIGrade").val() + "' data-color='" + $("#cboVOIColor").val() + "'>")
				.append('<td>' + $('#cboVOIModelYear').val() + '</td>')
				.append('<td>' + $('#cboVOIGrade').val() + '</td>')	
                .append('<td>' + $('#cboVOIColor').val() + '</td>')	
                .append('<td><button type="button" class="btn btn-block btn-sm btn-danger" onclick="delList(this)" style="z-index: 2; font-size: 18px; padding-top: 0px; padding-bottom: 0px; height: 26px; line-height: 26px;">&times;</button></td>')	
			);
		}
	}

	function checkList(model_year, grade, color){
		var exist = false;
		$("#tblVOIList tbody tr").each(function(){
			if($(this).find("td").eq(0).text()==model_year && $(this).find("td").eq(1).text()==grade && $(this).find("td").eq(2).text()==color){
				exist = true;
				return false;
			}
		});
		return exist;
	}

	function delList(obj){
		$(obj).parent().parent().remove();
	}	

	$("#txtMobileNo").focusout(function(){
		var mobile_no = $("#txtMobileNo").val();
		$.ajax({
			url: APP_URL + "api/sales/customer/check_customer.php",
			type: "POST",
			data: JSON.stringify({ mobile_no: mobile_no })
		}).done(function(data) {
			if(data.message=="duplicate"){
				bootbox.alert("This customer has already been registered with " + data.staff_name + ".");
			}
		});
	});	

	function getAllTownship(){
		$("#myModalTownshipList").modal('show');
		table = $('#myTable1').DataTable({
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"ajax": APP_URL + "api/township/get_all_rows.php"
		});
	} 

	$('#myTable1').on('click', 'tbody td', function(e){
		$("#myTable1 tbody tr").css("color","");
		$("#myTable1 tbody tr").css("background-color","");
		$(this).parent().css("background-color", "#e3ecf5");
		$(this).parent().css("color", "rgb(34, 126, 140)");

		$("#txtTownshipName").val($(this).parent().find("td").eq(2).text());
		$("#myModalTownshipList").modal('hide');
	});

	function getCustomer(){
		$("#myTable").find("tbody").find("tr").remove();
		$.ajax({
			url: APP_URL + "api/sales/customer/get_one_row.php",
			type: "POST",
			data: JSON.stringify({ id: ((cid)?cid:rid) })
		}).done(function(data) {
			$("#txtRegistrationNo").val(data.registration_no);
			$("#txtStaffName").attr("data-id", data.staff_id);
			$("#txtStaffName").text(data.staff_name);
			$("#txtSalesCenter").val(data.sales_center);

			if(data.gender==1){
				$("#chkGender").parent().addClass("off");
			}else{
				$("#chkGender").parent().removeClass("off");
			} 

			$("#txtName").val(data.name);
			$("#txtMobileNo").val(data.mobile_no);
			if(data.dob){
				$("#txtDatePicker1").val(data.dob);	
				$("#datePicker1").datepicker("setDate", data.dob);
			}else{
				$("#txtDatePicker1").val(customDate);
			}
			$("#txtDatePicker2").val(data.estimate_delivery_date);
			$("#datePicker2").datepicker("setDate", data.estimate_delivery_date);
			$("#txtDatePicker3").val(data.close_date);
			$("#datePicker3").datepicker("setDate", data.close_date);

			if(data.btc_am==1){
				$("#chkBTCAM").parent().removeClass("off");
			}
			if(data.btc_pm==1){
				$("#chkBTCPM").parent().removeClass("off");
			}

			if(data.soi_phone_inout==1){
				$("#chkSOIPhoneInOut").parent().removeClass("off");
			}
			if(data.soi_facebook==1){
				$("#chkSOIFacebook").parent().removeClass("off");
			}
			if(data.soi_advert==1){
				$("#chkSOIAdvert").parent().removeClass("off");
			}
			if(data.soi_road_show==1){
				$("#chkSOIRoadShow").parent().removeClass("off");
			}
			if(data.soi_television==1){
				$("#chkSOITelevision").parent().removeClass("off");
			}
			if(data.soi_website==1){
				$("#chkSOIWebsite").parent().removeClass("off");
			}
			if(data.soi_existing_customer==1){
				$("#chkSOIExistingCustomer").parent().removeClass("off");
			}
			if(data.soi_review==1){
				$("#chkSOIReview").parent().removeClass("off");
			}
			if(data.soi_walkin==1){
				$("#chkSOIWalkIn").parent().removeClass("off");
			}
			if(data.soi_car_magazine==1){
				$("#chkSOICarMagazine").parent().removeClass("off");
			}
			if(data.soi_broker==1){
				$("#chkSOIBroker").parent().removeClass("off"); 
			}
			if(data.soi_other==1){
				$("#chkSOIOther").parent().removeClass("off");
				$("#txtSOIOtherRemark").css("display", "");
				$("#txtSOIOtherRemark").val(data.soi_other_remark);
			}else{
				$("#txtSOIOtherRemark").css("display", "none");
				$("#txtSOIOtherRemark").val("");
			}

			var arrVOI = data.vehicle_of_interest.split("|");
			for (var i = 0; i < arrVOI.length; i++) {
				var model = arrVOI[i].split(";")[0];
				var year = arrVOI[i].split(";")[1];
				var grade = arrVOI[i].split(";")[2];
				var color = arrVOI[i].split(";")[3];
				$("#tblVOIList").find("tbody")
				.append($("<tr data-model-year='" + (model + ' - ' + year) + "' data-model='" + model + "' data-year='" + year + "' data-grade='" + grade + "' data-color='" + color + "'>")
					.append('<td>' + (model + ' - ' + year) + '</td>')
					.append('<td>' + grade + '</td>')	
	                .append('<td>' + color + '</td>')	
	                .append('<td><button type="button" class="btn btn-block btn-sm btn-danger" onclick="delList(this)" style="z-index: 2; font-size: 18px; padding-top: 0px; padding-bottom: 0px; height: 26px; line-height: 26px;">&times;</button></td>')	
				);
			}

			if(rid){
				$('button').prop("disabled", true);
			}

			$(".ssToggle").parent().addClass('off');
			if(data.sales_status=="Normal"){
				$("#chkSalesStatusNormal").parent().removeClass("off");
			}else if(data.sales_status=="Warm"){
				$("#chkSalesStatusWarm").parent().removeClass("off");
			}else if(data.sales_status=="Hot"){
				$("#chkSalesStatusHot").parent().removeClass("off");
			}else if(data.sales_status=="Deal"){
				$("#chkSalesStatusDeal").parent().removeClass("off");
			}

			if(data.sales_status=="Hot"){
				$("#txtDatePicker3").attr("disabled", true);
			}else{
				$("#txtDatePicker3").attr("disabled", false);
			}

			$("#txtNeedsRequirements").val(data.needs_requirements);
			$("#txtAlternativeTelephoneNo").val(data.alternative_telephone_no);
			$("#txtEmail").val(data.email);
			$("#txtHomePhone").val(data.home_phone);

			if(data.pcm_mobile==1){
				$("#chkPCMMobile").parent().removeClass("off");
			}
			if(data.pcm_email==1){
				$("#chkPCMEmail").parent().removeClass("off");
			}
			if(data.pcm_other==1){
				$("#chkPCMOther").parent().removeClass("off");
			}

			$("#txtBusiness").val(data.business);
			$("#txtAddress").val(data.address);
			$("#txtTownshipName").val(data.township);
			$("#txtCustomerHistory").val(data.customer_history);
			
			if(data.vip==1){
				$("#chkVIP").parent().removeClass("off");
			}

			$("#txtCVBrand").val(data.cv_brand);
			$("#cboCVModelYear").val(data.cv_model_year);
			$("#txtCVRTADNo1").val(data.cv_rtad_no); 
			$("#txtCVMileage1").val(data.cv_mileage);
			$("#txtCVMileage2").val(data.cv_mileage * 1000);

			if(data.cv_vehicle_as_commercial==1){
				$("#chkCVVehicleCommercial").parent().removeClass("off");
			}
			if(data.cvd_outstanding_payments==1){
				$("#chkCVOutstandingPayment").parent().removeClass("off");
			} 
			if(data.cv_private==1){
				$("#chkCVPrivate").parent().removeClass("off");
			}
			if(data.cv_business==1){
				$("#chkCVBusiness").parent().removeClass("off");
			}
			if(data.cv_off_road==1){
				$("#chkCVOffRoad").parent().removeClass("off");
			}
			if(data.cv_travelling==1){
				$("#chkCVTravelling").parent().removeClass("off");
			}

			$("#txtCVDislikeAboutCar").val(data.cv_dislike_about_car);
			$("#txtCVWouldYouLikeToHaveThatNotAlreadyHave").val(data.cv_would_you_like_to_have_that_not_already_have);
			$("#txtCVAnnualUsage").val(data.cv_annual_usage);
			$("#txtCVWhoWillBeUsingVehicle").val(data.cv_who_will_be_using_vehicle);

			$("#cboLifestyleFamilyMembers").val(data.lifestyle_family_members);
			$("#txtLifeStyleDreamBrand").val(data.lifestyle_dream_brand);
			$("#txtLifeStyleDreamCar").val(data.lifestyle_dream_car);
			$("#txtLifeStyleInterestedModel").val(data.lifestyle_interested_model);
			$("#txtLifestyleHobbiesInterests").val(data.lifestyle_hobbies_interests);
			$("#txtLifestyleExpectationsOfNewVehicle").val(data.lifestyle_expectations_of_new_vehicle);
		});
	}

	function detailview(){
		$("#btnSave").css("display","none");
		$('input').attr('disabled',true);
		$('textarea').attr('disabled',true);
		$('.form-control').attr("disabled", true);
		$('button').prop("disabled", true);
	}

	function validateAndSave(){	 
		var staff_id = $("#txtStaffName").attr("data-id");
		var staff_name = $("#txtStaffName").text();	
		var sales_center = $("#txtSalesCenter").val();

		var gender = ($("#chkGender").parent().hasClass("off"))?1:0;
		var name = $("#txtName").val();
		var mobile_no = $("#txtMobileNo").val();
		var dob = $("#txtDatePicker1").val();

		var btc_am = ($("#chkBTCAM").parent().hasClass("off"))?0:1;
		var btc_pm = ($("#chkBTCPM").parent().hasClass("off"))?0:1;

		var soi_phone_inout = ($("#chkSOIPhoneInOut").parent().hasClass("off"))?0:1;
		var soi_facebook = ($("#chkSOIFacebook").parent().hasClass("off"))?0:1;
		var soi_advert = ($("#chkSOIAdvert").parent().hasClass("off"))?0:1;
		var soi_road_show = ($("#chkSOIRoadShow").parent().hasClass("off"))?0:1;
		var soi_television = ($("#chkSOITelevision").parent().hasClass("off"))?0:1;
		var soi_website = ($("#chkSOIWebsite").parent().hasClass("off"))?0:1;
		var soi_existing_customer = ($("#chkSOIExistingCustomer").parent().hasClass("off"))?0:1;
		var soi_review = ($("#chkSOIReview").parent().hasClass("off"))?0:1;
		var soi_walkin = ($("#chkSOIWalkIn").parent().hasClass("off"))?0:1;
		var soi_car_magazine = ($("#chkSOICarMagazine").parent().hasClass("off"))?0:1;
		var soi_broker = ($("#chkSOIBroker").parent().hasClass("off"))?0:1; 
		var soi_other = ($("#chkSOIOther").parent().hasClass("off"))?0:1;
		var soi_other_remark = "";
		if(soi_other){
			soi_other_remark = $("#txtSOIOtherRemark").val();
		}

		var vehicle_of_interest = "";
		$("#tblVOIList tbody tr" ).each(function() {
			vehicle_of_interest = vehicle_of_interest + ((vehicle_of_interest!="")?"|":"") + $(this).attr("data-model") + ";" + $(this).attr("data-year") + ";" + $(this).attr("data-grade") + ";" + $(this).attr("data-color");
		});

		var sales_status = "";
		if($("#chkSalesStatusNormal").parent().hasClass("off")==false){
			sales_status = "Normal";
		}else if($("#chkSalesStatusWarm").parent().hasClass("off")==false){
			sales_status = "Warm";
		}else if($("#chkSalesStatusHot").parent().hasClass("off")==false){
			sales_status = "Hot";
		}else if($("#chkSalesStatusDeal").parent().hasClass("off")==false){
			sales_status = "Deal";
		}

		var needs_requirements = $("#txtNeedsRequirements").val();
		var estimate_delivery_date = $("#txtDatePicker2").val();
		var close_date = $("#txtDatePicker3").val();
		var alternative_telephone_no = $("#txtAlternativeTelephoneNo").val();
		var home_phone = $("#txtHomePhone").val();//wppp
		var email = $("#txtEmail").val();

		var pcm_mobile = ($("#chkPCMMobile").parent().hasClass("off"))?0:1;
		var pcm_email = ($("#chkPCMEmail").parent().hasClass("off"))?0:1;
		var pcm_other = ($("#chkPCMOther").parent().hasClass("off"))?0:1;

		var business = $("#txtBusiness").val();
		var township = $("#txtTownshipName").val();
		var address = $("#txtAddress").val();	
		var vip = ($("#chkVIP").parent().hasClass("off"))?0:1;
		var customer_history = $("#txtCustomerHistory").val();

		var cv_brand = $("#txtCVBrand").val();
		var cv_model_year = $("#cboCVModelYear").val();
		var str = $("#txtCVRTADNo1").val();
		var two = str.slice(str.length - 4);
		var one = str.replace(two, "");
		var cv_rtad_no = one +"-"+two;
		var cv_mileage = (isNaN(parseInt($("#txtCVMileage1").val()))==true)?"":parseInt($("#txtCVMileage1").val());
		var cv_vehicle_as_commercial = ($("#chkCVVehicleCommercial").parent().hasClass("off"))?0:1;
		var cvd_outstanding_payments = ($("#chkCVOutstandingPayment").parent().hasClass("off"))?0:1;
		var cv_private = ($("#chkCVPrivate").parent().hasClass("off"))?0:1;
		var cv_business = ($("#chkCVBusiness").parent().hasClass("off"))?0:1;
		var cv_off_road = ($("#chkCVOffRoad").parent().hasClass("off"))?0:1;
		var cv_travelling = ($("#chkCVTravelling").parent().hasClass("off"))?0:1;
		var cv_dislike_about_car = $("#txtCVDislikeAboutCar").val();
		var cv_would_you_like_to_have_that_not_already_have = $("#txtCVWouldYouLikeToHaveThatNotAlreadyHave").val();
		var cv_annual_usage = $("#txtCVAnnualUsage").val();
		var cv_who_will_be_using_vehicle = $("#txtCVWhoWillBeUsingVehicle").val();

		var lifestyle_family_members = $("#cboLifestyleFamilyMembers").val();
		var lifestyle_dream_brand = $("#txtLifeStyleDreamBrand").val();
		var lifestyle_dream_car = $("#txtLifeStyleDreamCar").val();
		var lifestyle_interested_model = $("#txtLifeStyleInterestedModel").val();
		var lifestyle_hobbies_interests = $("#txtLifestyleHobbiesInterests").val();
		var lifestyle_expectations_of_new_vehicle = $("#txtLifestyleExpectationsOfNewVehicle").val();

		if(sales_center.trim()==""){
			bootbox.alert("Please choose showroom/sales_center when you login.");
		}else if(name.trim()==""){
			bootbox.alert("Please fill name."); 
		}else if(mobile_no.trim()==""){
			bootbox.alert("Please fill mobile no."); 
		}else if(btc_am==0 && btc_pm==0){
			bootbox.alert("Please choose best time to call."); 
		}else if(soi_phone_inout==0 && soi_facebook==0 && soi_advert==0 && soi_road_show==0 && soi_television==0 && soi_website==0 && soi_existing_customer==0 && soi_review==0 && soi_walkin==0 && soi_car_magazine==0 && soi_broker==0 && soi_other==0){
			bootbox.alert("Please choose at least one source of inquiry."); 
		}else if(soi_other==1 && soi_other_remark.trim()==""){
			bootbox.alert("Please fill remark for other source of inquiry."); 
		}else if(vehicle_of_interest==""){
			bootbox.alert("Please choose at least one vehicle of interest."); 
		}else if(sales_status==""){
			bootbox.alert("Please choose sales status."); 
		}else if(township.trim()==""){
			bootbox.alert("Please fill township."); 
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/sales/customer/create.php",
				type: "POST",
				data: JSON.stringify({ staff_id: staff_id, staff_name: staff_name, sales_center: sales_center, gender: gender, name: name, mobile_no: mobile_no, dob: dob, vehicle_of_interest: vehicle_of_interest, btc_am: btc_am, btc_pm: btc_pm, soi_phone_inout: soi_phone_inout, soi_facebook: soi_facebook, soi_advert: soi_advert, soi_road_show: soi_road_show, soi_television: soi_television, soi_website: soi_website, soi_existing_customer: soi_existing_customer, soi_review: soi_review, soi_walkin: soi_walkin, soi_car_magazine: soi_car_magazine, soi_broker: soi_broker, soi_other: soi_other, soi_other_remark: soi_other_remark, sales_status: sales_status, needs_requirements: needs_requirements, estimate_delivery_date: estimate_delivery_date, close_date: close_date, alternative_telephone_no: alternative_telephone_no, email: email, home_phone: home_phone, pcm_mobile: pcm_mobile, pcm_email: pcm_email, pcm_other: pcm_other, business: business, township: township, address: address, vip: vip, customer_history: customer_history, cv_brand: cv_brand, cv_model_year: cv_model_year, cv_rtad_no: cv_rtad_no, cv_mileage: cv_mileage, cv_vehicle_as_commercial: cv_vehicle_as_commercial, cvd_outstanding_payments: cvd_outstanding_payments, cv_private: cv_private, cv_business: cv_business, cv_off_road: cv_off_road, cv_travelling: cv_travelling, cv_dislike_about_car: cv_dislike_about_car, cv_would_you_like_to_have_that_not_already_have: cv_would_you_like_to_have_that_not_already_have, cv_annual_usage: cv_annual_usage, cv_who_will_be_using_vehicle: cv_who_will_be_using_vehicle, lifestyle_family_members: lifestyle_family_members, lifestyle_dream_brand: lifestyle_dream_brand, lifestyle_dream_car: lifestyle_dream_car, lifestyle_interested_model: lifestyle_interested_model, lifestyle_hobbies_interests: lifestyle_hobbies_interests, lifestyle_expectations_of_new_vehicle: lifestyle_expectations_of_new_vehicle })
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="created"){
					// bootbox.confirm({
					// 	message: "<h4>Successfully Saved. Do you want to make test drive booking?</h4>",
					// 	buttons: {
					// 		confirm: {
					// 			label: '<span class="glyphicon glyphicon-ok"></span> Yes',
					// 			className: 'btn-primary'
					// 		},
					// 		cancel: {
					// 			label: '<span class="glyphicon glyphicon-remove"></span> No',
					// 			className: 'btn-danger'
					// 		}
					// 	},
					// 	callback: function (result) {
					// 		if(result){
					// 			gotoTestDriveBooking(data.customer_data_id);
					// 		}else{
					// 			document.location = APP_URL + "sales/customer_list.php";
					// 		}
					// 	}
					// });
					bootbox.alert("New lead successfully created.");
					clearForm();
					// document.location = APP_URL + "sales/customer_list.php";
				}else if(data.message=="duplicate"){
					bootbox.alert("This customer has already been registered with " + data.staff_name + ".");
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function validateAndUpdate(){	 
		var sales_center = $("#txtSalesCenter").val();
		var gender = ($("#chkGender").parent().hasClass("off"))?1:0;
		var name = $("#txtName").val();
		var mobile_no = $("#txtMobileNo").val();
		var dob = $("#txtDatePicker1").val(); 

		var btc_am = ($("#chkBTCAM").parent().hasClass("off"))?0:1;
		var btc_pm = ($("#chkBTCPM").parent().hasClass("off"))?0:1;

		var soi_phone_inout = ($("#chkSOIPhoneInOut").parent().hasClass("off"))?0:1;
		var soi_facebook = ($("#chkSOIFacebook").parent().hasClass("off"))?0:1;
		var soi_advert = ($("#chkSOIAdvert").parent().hasClass("off"))?0:1;
		var soi_road_show = ($("#chkSOIRoadShow").parent().hasClass("off"))?0:1;
		var soi_television = ($("#chkSOITelevision").parent().hasClass("off"))?0:1;
		var soi_website = ($("#chkSOIWebsite").parent().hasClass("off"))?0:1;
		var soi_existing_customer = ($("#chkSOIExistingCustomer").parent().hasClass("off"))?0:1;
		var soi_review = ($("#chkSOIReview").parent().hasClass("off"))?0:1;
		var soi_walkin = ($("#chkSOIWalkIn").parent().hasClass("off"))?0:1;
		var soi_car_magazine = ($("#chkSOICarMagazine").parent().hasClass("off"))?0:1;
		var soi_broker = ($("#chkSOIBroker").parent().hasClass("off"))?0:1; 
		var soi_other = ($("#chkSOIOther").parent().hasClass("off"))?0:1;
		var soi_other_remark = "";
		if(soi_other){
			soi_other_remark = $("#txtSOIOtherRemark").val();
		}

		var vehicle_of_interest = "";
		$("#tblVOIList tbody tr" ).each(function() {
			vehicle_of_interest = vehicle_of_interest + ((vehicle_of_interest!="")?"|":"") + $(this).attr("data-model") + ";" + $(this).attr("data-year") + ";" + $(this).attr("data-grade") + ";" + $(this).attr("data-color");
		});

		var sales_status = "";
		if($("#chkSalesStatusNormal").parent().hasClass("off")==false){
			sales_status = "Normal";
		}else if($("#chkSalesStatusWarm").parent().hasClass("off")==false){
			sales_status = "Warm";
		}else if($("#chkSalesStatusHot").parent().hasClass("off")==false){
			sales_status = "Hot";
		}else if($("#chkSalesStatusDeal").parent().hasClass("off")==false){
			sales_status = "Deal";
		}

		var needs_requirements = $("#txtNeedsRequirements").val();
		var estimate_delivery_date = $("#txtDatePicker2").val();
		var close_date = $("#txtDatePicker3").val();
		var alternative_telephone_no = $("#txtAlternativeTelephoneNo").val();
		var email = $("#txtEmail").val();
		var home_phone = $("#txtHomePhone").val();

		var pcm_mobile = ($("#chkPCMMobile").parent().hasClass("off"))?0:1;
		var pcm_email = ($("#chkPCMEmail").parent().hasClass("off"))?0:1;
		var pcm_other = ($("#chkPCMOther").parent().hasClass("off"))?0:1;

		var business = $("#txtBusiness").val();
		var township = $("#txtTownshipName").val();	
		var address = $("#txtAddress").val();
		var vip = ($("#chkVIP").parent().hasClass("off"))?0:1;
		var customer_history = $("#txtCustomerHistory").val();

		var cv_brand = $("#txtCVBrand").val();
		var cv_model_year = $("#cboCVModelYear").val();
		var cv_rtad_no = $("#txtCVRTADNo1").val();
		var cv_mileage = $("#txtCVMileage1").val();
		var cv_vehicle_as_commercial = ($("#chkCVVehicleCommercial").parent().hasClass("off"))?0:1;
		var cvd_outstanding_payments = ($("#chkCVOutstandingPayment").parent().hasClass("off"))?0:1;
		var cv_private = ($("#chkCVPrivate").parent().hasClass("off"))?0:1;
		var cv_business = ($("#chkCVBusiness").parent().hasClass("off"))?0:1;
		var cv_off_road = ($("#chkCVOffRoad").parent().hasClass("off"))?0:1;
		var cv_travelling = ($("#chkCVTravelling").parent().hasClass("off"))?0:1;
		var cv_dislike_about_car = $("#txtCVDislikeAboutCar").val();
		var cv_would_you_like_to_have_that_not_already_have = $("#txtCVWouldYouLikeToHaveThatNotAlreadyHave").val();
		var cv_annual_usage = $("#txtCVAnnualUsage").val();
		var cv_who_will_be_using_vehicle = $("#txtCVWhoWillBeUsingVehicle").val();

		var lifestyle_family_members = $("#cboLifestyleFamilyMembers").val();
		var lifestyle_dream_brand = $("#txtLifeStyleDreamBrand").val();
		var lifestyle_dream_car = $("#txtLifeStyleDreamCar").val();
		var lifestyle_interested_model = $("#txtLifeStyleInterestedModel").val();
		var lifestyle_hobbies_interests = $("#txtLifestyleHobbiesInterests").val();
		var lifestyle_expectations_of_new_vehicle = $("#txtLifestyleExpectationsOfNewVehicle").val();

		if(name.trim()==""){
			bootbox.alert("Please fill name."); 
		}else if(mobile_no.trim()==""){
			bootbox.alert("Please fill mobile no."); 
		}else if(btc_am==0 && btc_pm==0){
			bootbox.alert("Please choose best time to call."); 
			return false;
		}else if(soi_phone_inout==0 && soi_facebook==0 && soi_advert==0 && soi_road_show==0 && soi_television==0 && soi_website==0 && soi_existing_customer==0 && soi_review==0 && soi_walkin==0 && soi_car_magazine==0 && soi_broker==0 && soi_other==0){
			bootbox.alert("Please choose at least one source of inquiry."); 
		}else if(soi_other==1 && soi_other_remark.trim()==""){
			bootbox.alert("Please fill remark for other source of inquiry."); 
		}else if(vehicle_of_interest==""){
			bootbox.alert("Please choose at least one vehicle of interest."); 
		}else if(sales_status==""){
			bootbox.alert("Please choose sales status."); 
		}else if(township.trim()==""){
			bootbox.alert("Please fill township."); 
		}else{
			$("#loading").css("display","block");
			$.ajax({
				url: APP_URL + "api/sales/customer/update.php",
				type: "POST",
				data: JSON.stringify({ id: cid, sales_center: sales_center, gender: gender, name: name, mobile_no: mobile_no, dob: dob, vehicle_of_interest: vehicle_of_interest, btc_am: btc_am, btc_pm: btc_pm, soi_phone_inout: soi_phone_inout, soi_facebook: soi_facebook, soi_advert: soi_advert, soi_road_show: soi_road_show, soi_television: soi_television, soi_website: soi_website, soi_existing_customer: soi_existing_customer, soi_review: soi_review, soi_walkin: soi_walkin, soi_car_magazine: soi_car_magazine, soi_broker: soi_broker, soi_other: soi_other, soi_other_remark: soi_other_remark, sales_status: sales_status, needs_requirements: needs_requirements, estimate_delivery_date: estimate_delivery_date, close_date: close_date, alternative_telephone_no: alternative_telephone_no, email: email, home_phone: home_phone, pcm_mobile: pcm_mobile, pcm_email: pcm_email, pcm_other: pcm_other, business: business, township: township, address: address, vip: vip, customer_history: customer_history, cv_brand: cv_brand, cv_model_year: cv_model_year, cv_rtad_no: cv_rtad_no, cv_mileage: cv_mileage, cv_vehicle_as_commercial: cv_vehicle_as_commercial, cvd_outstanding_payments: cvd_outstanding_payments, cv_private: cv_private, cv_business: cv_business, cv_off_road: cv_off_road, cv_travelling: cv_travelling, cv_dislike_about_car: cv_dislike_about_car, cv_would_you_like_to_have_that_not_already_have: cv_would_you_like_to_have_that_not_already_have, cv_annual_usage: cv_annual_usage, cv_who_will_be_using_vehicle: cv_who_will_be_using_vehicle, lifestyle_family_members: lifestyle_family_members, lifestyle_dream_brand: lifestyle_dream_brand, lifestyle_dream_car: lifestyle_dream_car, lifestyle_interested_model: lifestyle_interested_model, lifestyle_hobbies_interests: lifestyle_hobbies_interests, lifestyle_expectations_of_new_vehicle: lifestyle_expectations_of_new_vehicle })
			}).done(function(data){
				$("#loading").css("display","none");
				if(data.message=="updated"){
					document.location = APP_URL + "sales/customer_list.php";
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}	

	function gotoTestDriveBooking(cid){
		document.location = APP_URL + "sales/test_drive_booking.php?act=entry&cid=" + cid;
	}

	function clearForm(){
		rid="";
		cid="";
		$("#txtStaffName").text('<?=$_SESSION['staff_name']?>');
		$("#txtStaffName").attr("data-id", '<?=$_SESSION['staff_id']?>');
		$("#txtSalesCenter").val("");
		$("#chkGender").parent().addClass("off");
		$("#txtName").val("");
		$("#txtMobileNo").val("");
		$("#txtDatePicker1").val(customDate);
		$("#datePicker1").datepicker("setDate", customDate);
		$("#txtDatePicker2").val(customDate);
		$("#datePicker2").datepicker("setDate", customDate);
		$("#txtDatePicker3").val(customDate);
		$("#datePicker3").datepicker("setDate", customDate);

		$("#chkBTCAM").parent().addClass("off");
		$("#chkBTCPM").parent().addClass("off");

		$("#chkSOIPhoneInOut").parent().addClass("off");
		$("#chkSOIFacebook").parent().addClass("off");
		$("#chkSOIAdvert").parent().addClass("off");
		$("#chkSOIRoadShow").parent().addClass("off");
		$("#chkSOITelevision").parent().addClass("off");
		$("#chkSOIWebsite").parent().addClass("off");
		$("#chkSOIExistingCustomer").parent().addClass("off");
		$("#chkSOIReview").parent().addClass("off");
		$("#chkSOIWalkIn").parent().addClass("off");
		$("#chkSOICarMagazine").parent().addClass("off");
		$("#chkSOIBroker").parent().addClass("off"); 
		$("#chkSOIOther").parent().addClass("off");
		$("#cboSOIOtherRemark").val("");
		getAllVehiclesNColor();
		$("#tblVOIList").find("tbody").find("tr").remove();

		$(".ssToggle").parent().addClass('off');
		$(".chkSalesStatusNormal").parent().removeClass('off');

		$("#txtNeedsRequirements").val("");
		$("#txtAlternativeTelephoneNo").val("");
		$("#txtEmail").val("");
		$("#txtHomePhone").val("");

		$("#chkPCMMobile").parent().addClass("off");
		$("#chkPCMEmail").parent().addClass("off");
		$("#chkPCMOther").parent().addClass("off");

		$("#txtBusiness").val("");
		$("#txtAddress").val("");
		$("#chkVIP").parent().addClass("off");
		
		$("#txtCVBrand").val("");
		$("#cboCVModelYear").val("");	
		$("#txtCVRTADNo1").val("");	 
		$("#txtCVMileage1").val("");
		$("#txtCVMileage2").val("");

		$("#chkCVVehicleCommercial").parent().addClass("off");
		$("#chkCVOutstandingPayment").parent().addClass("off");
		$("#chkCVPrivate").parent().addClass("off");
		$("#chkCVBusiness").parent().addClass("off");
		$("#chkCVOffRoad").parent().addClass("off");
		$("#chkCVTravelling").parent().addClass("off");

		$("#txtCVDislikeAboutCar").val("");	
		$("#txtCVWouldYouLikeToHaveThatNotAlreadyHave").val("");	
		$("#txtCVAnnualUsage").val("");
		$("#txtCVWhoWillBeUsingVehicle").val("");

		$("#cboLifestyleFamilyMembers").val("");
		$("#txtLifeStyleDreamBrand").val("");
		$("#txtLifeStyleDreamCar").val("");
		$("#txtLifeStyleInterestedModel").val("");
		$("#txtLifestyleHobbiesInterests").val("");
		$("#txtLifestyleExpectationsOfNewVehicle").val("");
	}

	function btozero(obj){
		if($(obj).val() == "" || $(obj).val() == "0")$(obj).val(0);
	}

	function isNumber(evt) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ( (charCode > 31 && charCode < 48) || charCode > 57) {
			return false;
		}
		return true;
	}
</script>	
