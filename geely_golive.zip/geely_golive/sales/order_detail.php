<?php include '../header.php'; ?>
<?php
	$oc_no = "";
	if(isset($_GET['oc_no'])){
		if(!empty($_GET['oc_no'])){
			$oc_no = $_GET['oc_no'];
		}
	}
?> 
<style>
	label{
		padding-top: 3px !important;
		padding-left: 0px !important;
		padding-right: 0px !important;
	}
	.input-group-addon{
		height: 36px !important;
	}
	#toggleStatus .active{
		background-color: #0062cc;
		border-color: #0062cc;
		color: #ffffff;
	}
	#toggleStatus .btn-group-toggle>label:hover{
		background-color: #0062cce3;
		border-color: #0062cce3;
		color: #ffffff;
	}
	#toggleStatus .btn-group-toggle>label{
		cursor: not-allowed !important;
		min-width: 100px;
		padding-top: 8px !important;
		padding-left: 8px !important;
		padding-right: 8px !important;
	}
	#toggleStatus .toggle{
		min-height: 31px !important;
	}
	.checkbox-inline {
		padding-top: 1px !important;
		margin-bottom: 0px !important;
	}
	.checkbox-inline .toggle{
		margin-left: 0px !important;
		width: 75px !important;
	}
	.toggle-on, .toggle-off{
		line-height: 25px !important;
		cursor: not-allowed !important;
	}
	.previewing{
		width: 100%;
		height: 135px;
		cursor: pointer; 
		object-fit: cover;
	}
	.displayNone{
		display: none;
	}
	.toggle{
		min-width: 100px !important;
	}
	.checkbox{
		float: right;
	}
	select{
		padding-top: 2px !important;
	}
</style> 
<div class="content-wrapper" style="min-height: 1203.6px;"> 
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<div class="col-md-6">
					<h1>Order Detail</h1>
				</div>
				<div class="col-md-6"></div>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12">
					<div class="card card-outline card-primary">
						<div class="card-header">
							<h3 class="card-title" style="font-weight: bold;" id="txtSalesCenter"><?=$_SESSION['sales_center'];?></h3>
							<input type="hidden" id="txtStaffID" value="">
						</div>
						<div class="overlay white" id="loading" style="display:none;position: absolute;width: 100%;height: 100%;z-index: 1000;">
							<i class="fas fa-3x fa-sync-alt rotate360"  style="margin: 70px 45%;"></i>
						</div>
						<form role="form" id="frmEntry">
							<div class="card-body">
								<div class="row" style="display:none;">
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">O.C No.:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtOCNo" disabled value="-">
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Order Date:</label>
											<div class="col-md-8">  
												<div class="input-group input-append date" id="datePicker" data-date="2020-02-07" data-date-format="yyyy-mm-dd">
													<div class="input-group-prepend">
														<span class="input-group-addon input-group-text" style="width: 40px; display: table-cell; height: 31px !important;">
															<i class="far fa-calendar-alt"></i>
														</span>
													</div>
													<input type="text" class="form-control float-right" id="txtDatePicker" value="1982-06-15" readonly>
												</div>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Sales Type:</label>
											<div class="col-md-8">
												<select class="form-control" id="cboSalesType">
													<option value="Fix">Fix</option>
													<option value="Staff">Staff</option>
													<option value="Retail">Retail</option> 
													<option value="Government">Government</option>
													<option value="Fleet">Fleet</option> 
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="row" style="padding-top: 9px;">
									<div class="col-md-12">
										<div class="card card-outline card-outline-tabs">
											<div class="card-header p-0 border-bottom-0">
												<ul class="nav nav-tabs" id="custom-tabs-four-tab" role="tablist">
													<li class="nav-item">
														<a class="nav-link active" id="custom-tabs-four-customer-tab" data-toggle="pill" href="#custom-tabs-four-customer" role="tab" aria-controls="custom-tabs-four-customer" aria-selected="true">Customer Info</a>
													</li>
													<li class="nav-item">
														<a class="nav-link" id="custom-tabs-four-rtad-tab" data-toggle="pill" href="#custom-tabs-four-rtad" role="tab" aria-controls="custom-tabs-four-rtad" aria-selected="false">RTAD Register Info</a>
													</li>
												</ul>
											</div>
											<div class="card-body">
												<div class="tab-content" id="custom-tabs-four-tabContent">
													<div class="tab-pane fade active show" id="custom-tabs-four-customer" role="tabpanel" aria-labelledby="custom-tabs-four-customer-tab">
														<div class="row brokerInfoPanel">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Broker Registration No.: </label>
																	<div class="col-md-8">
																		<input id="txtBrokerID" value='' class="form-control" style="display: none;" >
																			<input type="text" class="form-control" id="txtBrokerRegistrationNo" disabled style="border-radius: 3px;">  
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Broker Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtBrokerName" disabled>
																	</div>
																</div>
															</div>
														</div>
														<hr class="brokerInfoPanel">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Registration No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerRegistrationNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
																	<div class="col-md-8">
																		<input type="hidden" class="form-control" id="txtCustomerID" disabled>
																		<input type="text" class="form-control" id="txtCustomerName" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Type:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerType" disabled>
																	</div>
																</div>
																<div class="form-group row companyInfo" style="display: none;">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Company Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCompanyName" disabled>
																	</div>
																</div>
																<div class="form-group row companyInfo" style="display: none;">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Company Register No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCompanyRegisterNo" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.<span style="color: red; font-size: 20px;">*</span>:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerNRCNo" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtMobileNo" disabled onkeypress="return isNumber(event)">
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Email:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtEmail" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtCustomerTownship" disabled>
																	</div>
																</div>
															</div>
														</div>
													</div>
													<div class="tab-pane fade" id="custom-tabs-four-rtad" role="tabpanel" aria-labelledby="custom-tabs-four-rtad-tab">
														<div class="row">
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Same as Buyer:</label>
																	<div class="col-md-8">
																		<div class="input-group mb-3" style="margin-bottom: 0px !important;">
																			<div class="checkbox">
																				<label class="checkbox-inline" style="padding-left: 20px;">
																				    <input type="checkbox" data-toggle="toggle" id="chkSameAsBuyer" data-on="Yes" data-off="No" data-onstyle="success" data-offstyle="default" class="ssToggle" checked>
																				</label>
																			</div>
																		</div>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Name:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADName" disabled>
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">NRC No.<span style="color: red;font-size: 20px;">*</span>:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADNRCNo" disabled>
																	</div>
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Mobile No.:</label>
																	<div class="col-md-8">
																		<input type="text" class="form-control" id="txtRTADMobileNo" disabled onkeypress="return isNumber(event)">
																	</div>
																</div>
																<div class="form-group row">
																	<label class="col-md-4 col-form-label" style="text-align: right;">Township:</label>
																	<div class="col-md-8">
																		<div class="input-group input-group">
																			<input id="txtRTADTownship" value='' class="form-control" disabled>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								
								<!-- Vehicle Info -->
								<div class="row">
									<div class="col-md-12">
										<div class="card card-outline">
											<div class="card-header">
												<h3 class="card-title">Vehicle Info <span id="txtTotalRecord" style="font-weight: bold;"></span></h3>

												<!-- <div class="checkbox">
													<label class="checkbox-inline" style="padding-left: 20px;">
														<input type="checkbox" data-toggle="toggle" id="chkChangeToggle" data-on="Change" data-off="Change" data-onstyle="success">
													</label>
												</div> -->
											</div>
											<div class="card-body">
												<div class="row" style="padding-bottom: 12px;" id="toggleStatus">
													<div class="btn-group btn-group-toggle" data-toggle="buttons">
														<label class="btn btn-default active">
															<input type="radio" name="optStatus" class="vehicleDisabledEnabled" id="optInstock" value="Instock" autocomplete="off" checked disabled> Instock Sales
														</label>
														<label class="btn btn-default">
															<input type="radio" name="optStatus" class="vehicleDisabledEnabled" id="optPreorder" value="Preorder" autocomplete="off" disabled> Pre Order
														</label>
														<label class="btn btn-default">
															<input type="radio" name="optStatus" class="vehicleDisabledEnabled" id="optProduction" value="Production" autocomplete="off" disabled> Production Order
														</label> 
													</div>
												</div>
												<div class="row">
													<div class="col-md-6">
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Brand:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboBrand" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Model:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboModelName" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Model Year:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboModelYear" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Grade:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboGrade" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Exterior Color:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboExteriorColor" disabled></select>
															</div>
														</div>
														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;">Interior Color:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboInteriorColor" disabled></select>
															</div>
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group row VENo">
															<label class="col-md-4 col-form-label" style="text-align: right;">Vin No.:</label>
															<div class="col-md-8">
																<select class="form-control vehicleDisabledEnabled" id="cboVinNo" disabled></select>
															</div>
														</div>
														<div class="form-group row VENo">
															<label class="col-md-4 col-form-label" style="text-align: right;">Engine No.:</label>
															<div class="col-md-8">
																<input type="text" id="txtEngineNo" class="form-control" disabled value="" style="float:right;">
															</div>
														</div>

														<div class="form-group row">
															<label class="col-md-4 col-form-label" style="text-align: right;"></label>
															<div class="col-md-4">
																<img class="img-responsive previewing" id="InteriorImg" name="previewing" src="<?=$app_url;?>img/1.jpg">
															</div>
															<div class="col-md-4">
																<img class="img-responsive previewing" id="ExteriorImg" name="previewing" src="<?=$app_url;?>img/2.jpg">
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!-- Vehicle Info -->

								<!-- Calculation -->
								<div class="row" style="padding-top: 12px;">
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Code:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionCode" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Deposit:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtDeposit" value="1,000,000" style="text-align:right;" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Type:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPaymentType" disabled>
											</div>
										</div>
										<div class="form-group row connectHP">
											<label class="col-md-4 col-form-label" style="text-align: right;">Bank:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtBank" disabled>
											</div>
										</div>
										<div class="form-group row connectHP connectInHouse">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment (%):</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPaymentPercent" style="text-align:right;" disabled>
											</div>
										</div>
										<div class="form-group row connectHP connectInHouse">
											<label class="col-md-4 col-form-label" style="text-align: right;">Payment Term (Month):</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPaymentTerm" style="text-align:right;" disabled>
											</div>
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Vehicle Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtVehiclePrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Commercial Tax:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtCommercialTax" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Retail Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRetailPrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Registration Tax & Fees:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtRTADTax" value="0" style="text-align:right;" disabled>
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Total Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtTotalPrice" value="0" disabled style="text-align:right;">
											</div>
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Promotion Discount:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtPromotionDiscount" value="0" style="text-align:right;" disabled>
											</div>	
										</div>
										<div class="form-group row">
											<label class="col-md-4 col-form-label" style="text-align: right;">Selling Price:</label>
											<div class="col-md-8">
												<input type="text" class="form-control" id="txtSellingPrice" value="0" disabled style="text-align:right;">
											</div>
										</div> 
									</div>
								</div>
								<!-- Calculation -->
							</div>
						</form>
					</div>
				</div>
			</div>

		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>  
	var OCNO = '<?= $oc_no ?>';
	var d = new Date();
	var mm = (d.getMonth("MM")+1);
	var dd = d.getDate();
	var customDate = d.getFullYear() + "-" + ((mm<10)?"0" + mm:mm) + "-" +  ((dd<10)?"0" + dd:dd);

	$('#datePicker').attr("data-date",customDate);
	$("#txtDatePicker").val(customDate);

	$(function(){
		$("body").addClass("sidebar-collapse");
		$('#datePicker').datepicker();
		getOneOrder();
	});

	function getOneOrder(){
		$.ajax({
			url: APP_URL + "api/sales/order/get_one_order.php",
			type: "POST",
			data: JSON.stringify({ oc_no: OCNO })
		}).done(function(data) {
			$("#txtSalesCenter").text(data.sales_center);
			$("#txtOCNo").val(data.oc_no);
			$("#txtDatePicker").val(data.date);
			$("#datePicker").datepicker("setDate", data.date);
			$("#cboSalesType").val(data.sales_type);

            $("#txtStaffID").val(data.staff_id);

            // Broker Info
            if(parseInt(data.broker_id)>0){
            	$(".brokerInfoPanel").css("display", "");
				getAllBroker(); 
            }else{
            	$(".brokerInfoPanel").css("display", "none");
            }
			$("#txtBrokerID").val(data.broker_id);
			$("#txtBrokerRegistrationNo").val(data.b_registration_no);
			$("#txtBrokerName").val(data.broker_name);
			// Broker Info

			// Customer Info
			$("#txtCustomerRegistrationNo").val(data.c_registration_no);
			$("#txtCustomerID").val(data.customer_id);
			$("#txtCustomerName").val(data.customer_name);
			$("#txtMobileNo").val(data.c_mobile_no);
			$("#txtEmail").val(data.c_email);
			$("#txtCustomerTownship").val(data.c_township);
			$("#txtCustomerNRCNo").val(data.c_nrc_no);
			$("#txtCustomerType").val(data.customer_type);
			if(data.customer_type=="B2B"){
	   			$(".companyInfo").css("display", "");
	   			$("#txtCompanyName").val(data.company_name);
	   			$("#txtCompanyRegisterNo").val(data.company_register_no)
			}else{
	   		    $(".companyInfo").css("display", "none");
			}
			// Customer Info

			// RTAD Register Info
			if(data.same_as_buyer=="1"){
				$("#chkSameAsBuyer").parent().removeClass("off");
				$("#txtRTADName").attr("disabled", true);
				$("#cboRTADCode").attr("disabled", true);
				$("#cboRTADTownshipCode").attr("disabled", true);
				$("#cboRTADNRCType").attr("disabled", true);
				$("#txtRTADNRCNo").attr("disabled", true);
				$("#txtRTADMobileNo").attr("disabled", true);
				$("#btnTownship").attr("disabled", true);
			}else{
				$("#chkSameAsBuyer").parent().addClass("off");
				$("#txtRTADName").attr("disabled", false);
				$("#cboRTADCode").attr("disabled", false);
				$("#cboRTADTownshipCode").attr("disabled", false);
				$("#cboRTADNRCType").attr("disabled", false);
				$("#txtRTADNRCNo").attr("disabled", false);
				$("#txtRTADMobileNo").attr("disabled", false);
				$("#btnTownship").attr("disabled", false);		
			}

			$("#txtRTADName").val(data.rtad_name);
			$("#txtRTADMobileNo").val(data.rtad_mobile_no);
			$("#txtRTADTownship").val(data.rtad_township);
			$("#txtRTADNRCNo").val(data.rtad_nrc_no);
			
            // RTAD Register Info

            // Vehicle Info
			$("input[name='optStatus']:checked").parent().removeClass("active");
			$("#opt" + data.vehicle_status).prop("checked", true);
			$("#opt" + data.vehicle_status).parent().addClass("active");
			$(".VENo").css("display", "none");
			if(data.vehicle_status!="Production") $(".VENo").css("display", "");

			$("#cboBrand").append("<option value= '" + data.brand + "' data-id='" + data.brand.charAt(0).toUpperCase() + "' selected>" + data.brand + "</option>");
			$("#cboModelName").append("<option value= '" + data.model + "' selected>" + data.model + "</option>");
			$("#cboModelYear").append("<option value= '" + data.model_year + "' selected>" + data.model_year + "</option>");
			$("#cboGrade").append("<option value= '" + data.grade + "' selected>" + data.grade + "</option>");
			$("#cboExteriorColor").append("<option value= '" + data.exterior_color + "' selected>" + data.exterior_color + "</option>");
			$("#cboInteriorColor").append("<option value= '" + data.interior_color + "' selected>" + data.interior_color + "</option>");

			$("#cboVinNo").append("<option value= '" + data.vin_no + "' data-engine-no='" + data.engine_no + "' selected>" + data.vin_no + "</option>");
			$("#txtEngineNo").val(data.engine_no);

			if(data.interior_photo){
				$("#InteriorImg").attr("src", APP_URL + "upload/server/php/files/interior/" + data.car_list_id + "/" +  data.interior_photo);
			}
			if(data.exterior_photo){
				$("#ExteriorImg").attr("src", APP_URL + "upload/server/php/files/exterior/" + data.car_list_id + "/" +  data.exterior_photo);
			}
			// Vehicle Info

			$("#txtPaymentType").val(data.payment_type);
			if(data.payment_type=="HP"){
				$(".connectHP").css("display", "");
				$("#txtBank").val(data.bank);
				$("#txtPaymentTerm").val(data.payment_term);
				$("#txtPaymentPercent").val(data.payment_percent);
			}else if(data.payment_type=="InHouse"){
				$(".connectHP").css("display", "none");
				$(".connectInHouse").css("display", "");
				$("#txtPaymentTerm").val(data.payment_term);
				$("#txtPaymentPercent").val(data.payment_percent);
			}else{
				$(".connectHP").css("display", "none");
				$(".connectInHouse").css("display", "none");
			}

			$("#txtPromotionCode").val(data.promotion_code);
			$("#txtPromotionDiscount").val(data.promotion_discount);
			$("#txtVehiclePrice").val(data.vehicle_price);
			$("#txtRTADTax").val(data.rtad_tax);
			calculate();

			$("#txtDeposit").val(data.deposit);		
		});
	}

	function getAllBroker(){
		table = $('#myTableBroker').DataTable({ 
			"destroy": true,
			"paging": true,
			"lengthChange": true,
			"searching": true,
			"ordering": true,
			"info": true,
			"autoWidth": false,
			"responsive": true,
			"lengthMenu": [5, 10, 50, 100],
			"pageLength": 5,
			"order": [[ 0, "asc" ]],
			'columnDefs': [	
				{
					'targets': [1, 2],
					'searchable': false
				},
                { 
                    'targets': [1], 
                    'className': "displayNone" 
                }
			],
			"ajax": APP_URL + "api/sales/broker/get_all_rows.php"
		});		
	}

	function calculate(){
		var vehicle_price = parseInt($("#txtVehiclePrice").val().replace(/,/g, ''));
		var commercial_tax = Math.round(vehicle_price * 0.05);
		var promotion_discount = parseInt($("#txtPromotionDiscount").val().replace(/,/g, ''));
		var rtad_tax = parseInt($("#txtRTADTax").val().replace(/,/g, ''));

		var retail_price = vehicle_price + commercial_tax;
		var total_price = vehicle_price + commercial_tax + rtad_tax;
		var selling_price = total_price - promotion_discount;

		$("#txtVehiclePrice").val(vehicle_price.toLocaleString());
		$("#txtCommercialTax").val(commercial_tax.toLocaleString());
		$("#txtRetailPrice").val(retail_price.toLocaleString());
		$("#txtTotalPrice").val(total_price.toLocaleString());
		$("#txtSellingPrice").val(selling_price.toLocaleString());
	} 
</script>
