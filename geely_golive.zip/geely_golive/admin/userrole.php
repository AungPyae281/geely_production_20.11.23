<?php include '../header.php'; ?>
<?php
$name = "";
$dashboard = "";
if(isset($_GET['name'])){
	if(!empty($_GET['name'])){
		$name = $_GET['name'];
	}
}

if(isset($_GET['dashboard'])){
	if(!empty($_GET['dashboard'])){
		$dashboard = $_GET['dashboard'];
	}
}
?>	
<style>
	input[type=checkbox]{
		margin-right: 6px;
	}
</style>
<div class="content-wrapper">
	<section class="content-header">
		<div class="container-fluid">
			<div class="row mb-2">
				<h1>
					<?php if($name==""){ ?>
					Create User Role
					<?php }else{ ?>
					Edit User Role
					<?php } ?>
				</h1>
			</div>
		</div>
	</section>
	<section class="content">
		<div class="container-fluid">
			<div class="card card-outline card-primary">
				<div class="card-header">
					<h3 class="card-title">User Role</h3>
					<div class="card-tools">
						<button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i></button>	
					</div>
				</div>
				<form role="form" id="frmEntry">
					<div class="card-body">
						<div class="row">
							<div class="col-lg-5">
								<div class="form-group row">
									<label class="col-lg-4 col-form-label" style="text-align: right;">Dashboard:</label>
									<div class="col-lg-8">
										<select id="cboDashboard" class="form-control" style="padding-top: 1px;"> <?=((isset($_GET["name"]))?"readonly='readonly'":"")?>></select>
									</div>
								</div>
							</div>
							<div class="col-lg-5">
								<div class="form-group row">
									<input type="hidden" id="txtFormState" value="<?=((isset($_GET["name"]))?"Update":"Create")?>"/>
									<label class="col-lg-4 col-form-label" style="text-align: right;">Role Name:</label>
									<div class="col-lg-8">
										<input class="form-control" id="txtRoleName" type="text" maxlength="255" <?=((isset($_GET["name"]))?"readonly='readonly'":"")?>/>
									</div>
								</div>
							</div>
							<div class="col-lg-2"></div>
						</div>
						<div id="mainArea">
						
						</div>
						<div style="visibility: hidden;" id="processTemplate">
							<div class="form-group row">
								<label class="col-lg-1 col-form-label"></label>
								<div class="col-lg-9">
									<div class="panel-body" >	
										<div class="col-lg-4 icheck-success d-inline">
											<input type="checkbox" class="chkProcess">
											<label class="processName">-</label>
										</div>
									</div>
								</div>
								<div class="col-lg-12 accessArea">
									<label class="col-lg-2 col-form-label"></label>
									<div class="col-lg-9">
										<div class="panel-body">
											<div class="col-lg-2 custom-control custom-checkbox">
											  <input class="custom-control-input" type="checkbox">
											  <label class="custom-control-label">Create</label>
											</div>
											<div class="col-lg-2 custom-control custom-checkbox">
											  <input class="custom-control-input" type="checkbox">
											  <label class="custom-control-label">Read</label>
											</div>
											<div class="col-lg-2 custom-control custom-checkbox">
											  <input class="custom-control-input" type="checkbox">
											  <label class="custom-control-label">Update</label>
											</div>
											<div class="col-lg-2 custom-control custom-checkbox">
											  <input class="custom-control-input" type="checkbox">
											  <label class="custom-control-label">Delete</label>
											</div>
											<div class="col-lg-2 custom-control custom-checkbox">
											  <input class="custom-control-input" type="checkbox">
											  <label class="custom-control-label">Export</label>
											</div>
											<div class="col-lg-2 custom-control custom-checkbox">
											  <input class="custom-control-input" type="checkbox">
											  <label class="custom-control-label">Print</label>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="form-group row">
							<div class="col-md-6"></div>
							<?php if($name==""){ ?>
							<div class="col-md-4" style="text-align: right;">
								<button class="btn btn-info" type="button" onclick="clearForm()">Clear</button>
								<button id="btnSubmit" class="btn btn-success" type="button" value="Create" onclick="saveAndUpdate()">Create</button>
							</div> 
							<?php }else{ ?> 
							<div class="col-md-4" style="text-align: right;">
								<button id="btnSubmit" class="btn btn-info" type="button" value="Update" onclick="saveAndUpdate()">Update</button>
							</div>
							<?php } ?>
							<div class="col-md-2"></div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</section>
</div>
<?php include '../footer.php'; ?>
<script>	
	var roleName = '<?=$name;?>';
	var DASHBOARD = '<?=$dashboard;?>';
	var arrChkGroup = ["Create", "Read", "Update", "Delete", "Export", "Print"];
		
	$(function(){
		if(roleName!=""){
			$("#txtRoleName").val(roleName);
		}
		getAllDashboard();
	});

	$("#cboDashboard").change(function(){
		getAllProcessWithAccess();
	});

	$(document).on("click", ".chkProcess", function() {
		if($(this).is(":checked")){
			$(this).closest(".row").find(".accessArea").find("input").prop("checked", false);
			$(this).closest(".row").find(".accessArea").show();
			$(this).closest(".row").find(".accessArea").find("input[type=checkbox]").not(":disabled").prop("checked", true);
		}else{
			$(this).closest(".row").find(".accessArea").hide();
			$(this).closest(".row").find(".accessArea").find("input[type=checkbox]").not(":disabled").prop("checked", false);
		}
	});

	function getAllDashboard(){
		$("#cboDashboard").find("option").remove();
		$.ajax({
	        url: APP_URL + "api/process/get_all_dashboard.php"
	    }).done(function(data) {
	        $.each(data.records, function(i, v) {
		    	var dashb = "";
		    	if(v.dashboard=="hr"){
		    		dashb = "HR";
		    	}else{
		    		var arrD = v.dashboard.split("_");
		    		for (var x = 0; x < arrD.length; x++) {
		    			dashb += ((dashb!="")?" ":"") + arrD[x].charAt(0).toUpperCase() + arrD[x].slice(1);
		    		}
		    	}
		    	if(DASHBOARD==dashb){
					$("#cboDashboard").append("<option value='" + v.dashboard + "' selected>" + dashb + "</option>");
		    	}else{
					$("#cboDashboard").append("<option value='" + v.dashboard + "'>" + dashb + "</option>");
		    	}
	        });
	    	getAllProcessWithAccess(); 
	    }); 
	}

	function getAllProcessWithAccess(){
		$("#mainArea").empty();
		var dashboard = (DASHBOARD)?DASHBOARD.toLowerCase().replace(" ", "_"):$("#cboDashboard").val();
	    $.ajax({
	        url: APP_URL + "api/process/get_all_process_with_access.php",
	        type: "POST",
	        data: JSON.stringify({ dashboard: dashboard })
	    }).done(function(data) {
			var moduleName = "";
	        $.each(data.records, function(i, v) {
				if(moduleName!=v.module){
					$("#mainArea").append("<h5 class='module'><span style='font-weight: bold;margin-left:10px;'>" + v.module + "</span></h5><legend> </legend>");
				}
				var $process = $("#processTemplate").clone();
				$process.find(".processName").text(v.process);
				$process.find(".processName").attr("for", "chk" + v.process.replace(/ /g, ''));
				$process.find(".chkProcess").attr("id", "chk" + v.process.replace(/ /g, '')); 

				for (var j = 0; j <= 5; j++) {
					$process.find(".accessArea").eq(0).find("input").eq(j).attr("id", "chk" + v.process.replace(/ /g, '') + arrChkGroup[j]);
					$process.find(".accessArea").eq(0).find("input").eq(j).next().attr("for", "chk" + v.process.replace(/ /g, '') + arrChkGroup[j]);
				}
				$process.find(".accessArea").hide();
				
				if(v.create == "0") $process.find(".accessArea").eq(0).find("input").eq(0).prop("disabled",true);
				if(v.read == "0") $process.find(".accessArea").eq(0).find("input").eq(1).prop("disabled",true);
				if(v.update == "0") $process.find(".accessArea").eq(0).find("input").eq(2).prop("disabled",true);
				if(v.delete == "0") $process.find(".accessArea").eq(0).find("input").eq(3).prop("disabled",true);
				if(v.export == "0") $process.find(".accessArea").eq(0).find("input").eq(4).prop("disabled",true);
				if(v.print == "0") $process.find(".accessArea").eq(0).find("input").eq(5).prop("disabled",true);

				$("#mainArea").append($process.html());
				moduleName = v.module;
	        }); 
			if(DASHBOARD!=""){
	    		$("#cboDashboard").attr("disabled",  true);
	    		getRoleNameProcess();
	    	}
	    }); 
	}

	function validate(){
		if($("#txtRoleName").val().trim()==""){bootbox.alert("User Role shouldn't be blank.");return false;}
		return true;
	} 

	function clearForm(){
		$("#frmEntry")[0].reset();
		$("#txtRoleName").val(rn);
	}

	function saveAndUpdate(){
		if(validate()){		
			if($("#txtFormState").val()=="Create"){
				$.ajax({
					type: "POST",
					url: APP_URL + "api/userrole/is_exist.php",
					data: JSON.stringify({ role_name: $("#txtRoleName").val()})
				}).done(function(data){	
					if(!data.message){
						callCreate();
					}else{
						bootbox.alert("Role name already exist. Please try another name.");
					}
				});
			}else{
				callCreate();
			}
		}
	}

	function callCreate(){	
		var processes = [];
		$('.accessArea').each(function() {
			if($(this).closest(".row").find(".chkProcess").is(":checked")){
				var create = $(this).find("input[type=checkbox]").eq(0).is(":checked");
				var read = $(this).find("input[type=checkbox]").eq(1).is(":checked");
				var update = $(this).find("input[type=checkbox]").eq(2).is(":checked");
				var del = $(this).find("input[type=checkbox]").eq(3).is(":checked");
				var exp = $(this).find("input[type=checkbox]").eq(4).is(":checked");
				var print = $(this).find("input[type=checkbox]").eq(5).is(":checked");

				if(create || read || update || del || exp || print){
					var role = {
						"process" : $(this).closest(".row").find(".processName").eq(0).text(),
						"create" : $(this).find("input[type=checkbox]").eq(0).is(":checked"),
						"read" : $(this).find("input[type=checkbox]").eq(1).is(":checked"),
						"update" : $(this).find("input[type=checkbox]").eq(2).is(":checked"),
						"delete" : $(this).find("input[type=checkbox]").eq(3).is(":checked"),
						"export" : $(this).find("input[type=checkbox]").eq(4).is(":checked"),
						"print" : $(this).find("input[type=checkbox]").eq(5).is(":checked")
					}
					processes.push(role);
				}
			}
		});

		if(processes.length==0){
			bootbox.alert("Please marks on the checkbox.");
			$("#loading").css("display", "none");
			return false;
		}else{	
			$.ajax({
				type: "POST",
				url: APP_URL + "api/userrole/create.php",
				data: JSON.stringify({ dashboard: $("#cboDashboard").val(), role_name: $("#txtRoleName").val(), processes: processes })
			}).done(function(data){	
				if(data.message == "created"){
					if($("#txtFormState").val()=="Create"){
						bootbox.alert("User role created.");
						$("#txtRoleName").val("");
						getAllDashboard();
					}else{
						bootbox.alert("User role updated.");
						//redirect back to user role list page.
					}
				}else{
					bootbox.alert("Error on server side.");
				}
			});
		}
	}

	function getRoleNameProcess(){
	 	$.ajax({
	 		url: APP_URL + "api/userrole/get_process.php",
	 		type: "POST",
	 		data: JSON.stringify({ role_name: roleName })
	 	}).done(function(data){	
	 		$.each(data.records, function(i, v) {
				$(".processName").each(function(){
					if($(this).text()==v.process){
						$(this).closest(".row").find("input[type=checkbox]").eq(0).prop("checked", true);
						$(this).closest(".row").find(".accessArea").eq(0).css("display", "");
						$(this).closest(".row").find("input[type=checkbox]").eq(1).prop("checked", (v.create=="1")?true:false);
						$(this).closest(".row").find("input[type=checkbox]").eq(2).prop("checked", (v.read=="1")?true:false);
						$(this).closest(".row").find("input[type=checkbox]").eq(3).prop("checked", (v.update=="1")?true:false);
						$(this).closest(".row").find("input[type=checkbox]").eq(4).prop("checked", (v.delete=="1")?true:false);
						$(this).closest(".row").find("input[type=checkbox]").eq(5).prop("checked", (v.export=="1")?true:false);
						$(this).closest(".row").find("input[type=checkbox]").eq(6).prop("checked", (v.print=="1")?true:false);
					}
				});	
			});
	 	});
	}
</script>	